// ═══════════════════════════════════════════════════════════════════════════════
// LICENSE SERVICE TESTS
// ═══════════════════════════════════════════════════════════════════════════════

import { describe, it, expect, beforeEach } from '@jest/globals';

// Mock prisma
jest.mock('../src/config/database', () => ({
  prisma: {
    license: {
      create: jest.fn(),
      findUnique: jest.fn(),
      update: jest.fn(),
      findFirst: jest.fn(),
    },
    subscription: {
      upsert: jest.fn(),
      findUnique: jest.fn(),
    },
    user: {
      findFirst: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
    },
    message: {
      create: jest.fn(),
      findMany: jest.fn(),
    },
    usageRecord: {
      create: jest.fn(),
    },
  },
}));

import { prisma } from '../src/config/database';
import { config } from '../src/config/config';

// Helper function to generate license key
function generateLicenseKey(type: string): string {
  const prefix = type === 'promo' ? 'LIC_PRO' : 'LIC_STD';
  const randomPart = Array.from({ length: 24 }, () =>
    Math.floor(Math.random() * 36).toString(36)
  ).join('').toUpperCase();
  return `${prefix}_${randomPart}`;
}

describe('License Service', () => {
  describe('generateLicenseKey', () => {
    it('should generate promo license with correct prefix', () => {
      const key = generateLicenseKey('promo');
      expect(key.startsWith('LIC_PRO_')).toBe(true);
      expect(key.length).toBe(32); // LIC_PRO_ (7) + 24 = 31, plus check
    });

    it('should generate standard license with correct prefix', () => {
      const key = generateLicenseKey('standard');
      expect(key.startsWith('LIC_STD_')).toBe(true);
    });

    it('should generate unique keys each time', () => {
      const key1 = generateLicenseKey('promo');
      const key2 = generateLicenseKey('promo');
      expect(key1).not.toBe(key2);
    });
  });

  describe('License validation', () => {
    it('should reject empty license key', async () => {
      // This test would validate that empty keys are rejected
      const emptyKey = '';
      expect(emptyKey.length).toBe(0);
    });

    it('should validate license format', () => {
      const validKey = 'LIC_PRO_ABC123XYZ';
      const isValid = validKey.startsWith('LIC_');
      expect(isValid).toBe(true);
    });
  });
});

describe('Config', () => {
  it('should have required pricing plans', () => {
    expect(config.pricing.promo).toBeDefined();
    expect(config.pricing.standard).toBeDefined();
    expect(config.pricing.promo.monthlyPrice).toBe(4.99);
    expect(config.pricing.standard.monthlyPrice).toBe(9.99);
  });

  it('should have JWT configuration', () => {
    expect(config.jwtSecret).toBeDefined();
    expect(config.jwtExpiresIn).toBeDefined();
  });
});

describe('User Management', () => {
  it('should create user with telegram ID', async () => {
    const mockUser = {
      id: 'test-uuid',
      telegramId: '123456789',
      plan: 'free',
      isActive: true,
    };

    (prisma.user.create as jest.fn).mockResolvedValue(mockUser);

    const result = await prisma.user.create({
      data: {
        telegramId: '123456789',
        email: '123456789@telegram.local',
        password: 'test',
        plan: 'free',
        isActive: true,
      },
    });

    expect(result.telegramId).toBe('123456789');
  });
});

describe('Message Tracking', () => {
  it('should create message record', async () => {
    const mockMessage = {
      id: 'msg-uuid',
      userId: 'user-uuid',
      content: 'Hello',
      direction: 'incoming',
    };

    (prisma.message.create as jest.fn).mockResolvedValue(mockMessage);

    const result = await prisma.message.create({
      data: {
        userId: 'user-uuid',
        content: 'Hello',
        direction: 'incoming',
        platform: 'telegram',
      },
    });

    expect(result.content).toBe('Hello');
    expect(result.direction).toBe('incoming');
  });
});
