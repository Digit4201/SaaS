// ═══════════════════════════════════════════════════════════════════════════════
// API INTEGRATION TESTS - Telegram AI SaaS
// ═══════════════════════════════════════════════════════════════════════════════

import { describe, it, expect, beforeAll, afterAll, beforeEach } from '@jest/globals';
import Fastify, { FastifyInstance } from 'fastify';
import { buildApp } from '../src/index.js';
import { prisma } from '../src/config/database.js';

describe('API Integration Tests', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = await buildApp();
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
    await prisma.$disconnect();
  });

  // ═══════════════════════════════════════════════════════════════════════
  // HEALTH CHECK TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('Health Endpoints', () => {
    it('GET /health should return healthy status', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/health'
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.status).toBe('healthy');
    });

    it('GET /metrics should return prometheus format', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/metrics'
      });

      expect(response.statusCode).toBe(200);
      expect(response.headers['content-type']).toContain('text/plain');
    });
  });

  // ═══════════════════════════════════════════════════════════════════════
  // BILLING TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('Billing Endpoints', () => {
    it('GET /billing/plans should return plans', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/billing/plans'
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.promo).toBeDefined();
      expect(body.data.standard).toBeDefined();
    });
  });

  // ═══════════════════════════════════════════════════════════════════════
  // AUTH TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('Auth Endpoints', () => {
    const testTelegramId = `test_${Date.now()}`;

    it('POST /auth/register should create user', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/auth/register',
        payload: {
          telegramId: testTelegramId,
          telegramUsername: 'testuser',
          telegramFirstName: 'Test'
        }
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.user.telegramId).toBe(testTelegramId);
      expect(body.data.token).toBeDefined();
    });

    it('POST /auth/login should reject invalid credentials', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/auth/login',
        payload: {
          email: 'nonexistent@test.com',
          password: 'wrongpassword'
        }
      });

      expect(response.statusCode).toBe(401);
    });
  });

  // ═══════════════════════════════════════════════════════════════════════
  // TELEGRAM WEBHOOK TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('Telegram Webhook', () => {
    it('POST /telegram/webhook should accept valid updates', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/telegram/webhook',
        headers: {
          'x-telegram-bot-api-secret-token': 'test-secret'
        },
        payload: {
          update_id: 12345,
          message: {
            message_id: 67890,
            from: {
              id: Date.now(),
              username: 'webhook_test',
              first_name: 'Webhook'
            },
            text: 'Test message',
            date: Math.floor(Date.now() / 1000)
          }
        }
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
    });

    it('POST /telegram/webhook should reject invalid secret', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/telegram/webhook',
        headers: {
          'x-telegram-bot-api-secret-token': 'wrong-secret'
        },
        payload: {
          update_id: 12345,
          message: {
            message_id: 67890,
            from: { id: 999 },
            text: 'Test',
            date: Math.floor(Date.now() / 1000)
          }
        }
      });

      expect(response.statusCode).toBe(403);
    });
  });

  // ═══════════════════════════════════════════════════════════════════════
  // LICENSE TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('License Endpoints', () => {
    let authToken: string;

    beforeAll(async () => {
      // Register test user
      const registerResponse = await app.inject({
        method: 'POST',
        url: '/auth/register',
        payload: {
          telegramId: `license_test_${Date.now()}`,
          telegramUsername: 'licenseuser'
        }
      });

      const registerBody = JSON.parse(registerResponse.body);
      authToken = registerBody.data.token;
    });

    it('GET /license/status should return without license', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/license/status',
        headers: {
          authorization: `Bearer ${authToken}`
        }
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.body);
      expect(body.success).toBe(true);
      expect(body.data.hasLicense).toBe(false);
    });

    it('POST /license/verify should reject invalid key', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/license/verify',
        payload: {
          licenseKey: 'INVALID_KEY'
        }
      });

      expect(response.statusCode).toBe(400);
    });
  });

  // ═══════════════════════════════════════════════════════════════════════
  // RATE LIMITING TESTS
  // ═══════════════════════════════════════════════════════════════════════

  describe('Rate Limiting', () => {
    it('should accept requests within limit', async () => {
      // Make 5 rapid requests
      for (let i = 0; i < 5; i++) {
        const response = await app.inject({
          method: 'GET',
          url: '/health'
        });
        expect(response.statusCode).toBe(200);
      }
    });
  });
});

describe('Database Integration', () => {
  beforeAll(async () => {
    await prisma.$connect();
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('should connect to database', async () => {
    const result = await prisma.$queryRaw`SELECT 1 as result`;
    expect(result).toBeDefined();
  });

  it('should create and query users', async () => {
    const testUserId = `db_test_${Date.now()}`;
    
    // Create
    const user = await prisma.user.create({
      data: {
        telegramId: testUserId,
        email: `${testUserId}@test.local`,
        isActive: true
      }
    });

    expect(user.telegramId).toBe(testUserId);

    // Query
    const found = await prisma.user.findUnique({
      where: { telegramId: testUserId }
    });

    expect(found).toBeDefined();
    expect(found?.telegramId).toBe(testUserId);

    // Cleanup
    await prisma.user.delete({
      where: { id: user.id }
    });
  });
});
