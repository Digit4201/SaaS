// ═══════════════════════════════════════════════════════════════════════════════
// USAGE - Usage Tracking Routes
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';

export async function usageRoutes(fastify: FastifyInstance) {
  // Get current usage
  fastify.get('/usage', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const subscription = await prisma.subscription.findUnique({
        where: { userId: user.userId }
      });

      if (!subscription) {
        return {
          success: true,
          data: {
            used: 0,
            limit: 0,
            percentage: 0,
            remaining: 0
          }
        };
      }

      const used = subscription.creditsUsed;
      const limit = subscription.monthlyCredits;
      const percentage = Math.round((used / limit) * 100);

      return {
        success: true,
        data: {
          used,
          limit,
          percentage: Math.min(percentage, 100),
          remaining: Math.max(limit - used, 0),
          resetDate: subscription.creditsResetAt,
          plan: subscription.plan
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get usage');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get usage'
      });
    }
  });

  // Get usage history
  fastify.get('/usage/history', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const days = parseInt((request.query as any).days || '30', 10);

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const records = await prisma.usageRecord.findMany({
        where: {
          userId: user.userId,
          createdAt: { gte: startDate }
        },
        orderBy: { createdAt: 'desc' }
      });

      // Aggregate by type
      const byType = records.reduce((acc, record) => {
        acc[record.recordType] = (acc[record.recordType] || 0) + record.amount;
        return acc;
      }, {} as Record<string, number>);

      return {
        success: true,
        data: {
          records,
          byType,
          total: records.reduce((acc, r) => acc + r.amount, 0)
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get usage history');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get usage history'
      });
    }
  });

  // Get message history
  fastify.get('/usage/messages', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const limit = parseInt((request.query as any).limit || '50', 10);

      const messages = await prisma.message.findMany({
        where: { userId: user.userId },
        orderBy: { createdAt: 'desc' },
        take: limit
      });

      return {
        success: true,
        data: messages.reverse()
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get messages');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get messages'
      });
    }
  });
}
