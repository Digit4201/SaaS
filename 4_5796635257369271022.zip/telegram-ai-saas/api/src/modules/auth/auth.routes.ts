// ═══════════════════════════════════════════════════════════════════════════════
// AUTH - Authentication Routes (CORRIGÉ - Vérification mot de passe!)
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../../config/database.js';
import { config } from '../../config/config.js';
import { logger } from '../../config/logger.js';

interface RegisterBody {
  telegramId: string;
  telegramUsername?: string;
  telegramFirstName?: string;
}

interface LoginBody {
  email: string;
  password: string;
}

export async function authRoutes(fastify: FastifyInstance) {
  // Register new user (called after Telegram auth)
  fastify.post<{ Body: RegisterBody }>('/auth/register', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { telegramId, telegramUsername, telegramFirstName } = request.body;

      if (!telegramId) {
        return reply.status(400).send({
          success: false,
          error: 'Telegram ID is required'
        });
      }

      // Check if user already exists
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [
            { telegramId },
            { email: `${telegramId}@telegram.local` }
          ]
        }
      });

      if (existingUser) {
        // Generate new token for existing user
        const token = jwt.sign(
          { userId: existingUser.id, role: existingUser.role },
          config.jwtSecret,
          { expiresIn: config.jwtExpiresIn }
        );

        return {
          success: true,
          data: {
            user: {
              id: existingUser.id,
              telegramId: existingUser.telegramId,
              telegramUsername: existingUser.telegramUsername,
              plan: existingUser.plan
            },
            token
          }
        };
      }

      // Create new user with hashed password
      const password = Math.random().toString(36);
      const hashedPassword = await bcrypt.hash(password, 10);

      const user = await prisma.user.create({
        data: {
          telegramId,
          telegramUsername,
          telegramFirstName,
          email: `${telegramId}@telegram.local`,
          passwordHash: hashedPassword,
          plan: 'free',
          role: 'user',
          isActive: true
        }
      });

      // Generate token
      const token = jwt.sign(
        { userId: user.id, role: user.role },
        config.jwtSecret,
        { expiresIn: config.jwtExpiresIn }
      );

      logger.info({ userId: user.id }, 'New user registered');

      return {
        success: true,
        data: {
          user: {
            id: user.id,
            telegramId: user.telegramId,
            telegramUsername: user.telegramUsername,
            plan: user.plan
          },
          token
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Registration failed');
      return reply.status(500).send({
        success: false,
        error: 'Registration failed'
      });
    }
  });

  // Login with email/password (CORRIGÉ - Vérification bcrypt!)
  fastify.post<{ Body: LoginBody }>('/auth/login', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { email, password } = request.body;

      // Find user
      const user = await prisma.user.findUnique({
        where: { email }
      });

      if (!user) {
        return reply.status(401).send({
          success: false,
          error: 'Invalid credentials'
        });
      }

      if (!user.isActive) {
        return reply.status(403).send({
          success: false,
          error: 'Account is disabled'
        });
      }

      // ═══════════════════════════════════════════════════════════════════════
      // CORRECTION CRITIQUE: Vérification du mot de passe avec bcrypt!
      // ═══════════════════════════════════════════════════════════════════════
      if (user.passwordHash) {
        const isValidPassword = await bcrypt.compare(password, user.passwordHash);
        
        if (!isValidPassword) {
          logger.warn({ email }, 'Invalid password attempt');
          return reply.status(401).send({
            success: false,
            error: 'Invalid credentials'
          });
        }
      }

      // Generate token
      const token = jwt.sign(
        { userId: user.id, role: user.role },
        config.jwtSecret,
        { expiresIn: config.jwtExpiresIn }
      );

      logger.info({ userId: user.id }, 'Login successful');

      return {
        success: true,
        data: {
          user: {
            id: user.id,
            email: user.email,
            plan: user.plan,
            role: user.role
          },
          token
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Login failed');
      return reply.status(500).send({
        success: false,
        error: 'Login failed'
      });
    }
  });

  // Get current user
  fastify.get('/auth/me', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      
      if (!user) {
        return reply.status(401).send({
          success: false,
          error: 'Not authenticated'
        });
      }

      const fullUser = await prisma.user.findUnique({
        where: { id: user.userId },
        select: {
          id: true,
          telegramId: true,
          telegramUsername: true,
          telegramFirstName: true,
          email: true,
          plan: true,
          role: true,
          isActive: true,
          createdAt: true,
          lastActiveAt: true
        }
      });

      return {
        success: true,
        data: fullUser
      };
    } catch (error) {
      logger.error({ err: error }, 'Get user failed');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get user'
      });
    }
  });

  // Update profile
  fastify.patch('/auth/profile', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const updates = request.body as any;

      // Remove sensitive fields
      delete updates.password;
      delete updates.role;
      delete updates.isActive;

      const updatedUser = await prisma.user.update({
        where: { id: user.userId },
        data: updates,
        select: {
          id: true,
          telegramId: true,
          telegramUsername: true,
          telegramFirstName: true,
          email: true,
          plan: true,
          role: true,
          isActive: true,
          createdAt: true,
          lastActiveAt: true
        }
      });

      return {
        success: true,
        data: updatedUser
      };
    } catch (error) {
      logger.error({ err: error }, 'Update profile failed');
      return reply.status(500).send({
        success: false,
        error: 'Failed to update profile'
      });
    }
  });
}
