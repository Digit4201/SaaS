// ═══════════════════════════════════════════════════════════════════════════════
// TELEGRAM - Bot Routes (CORRIGÉ)
// ═══════════════════════════════════════════════════════════════════════════════
// NOTE: Le bot répond maintenant aux utilisateurs!
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/config.js';
import * as crypto from 'crypto';

interface TelegramWebhookBody {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      username?: string;
      first_name?: string;
      language_code?: string;
    };
    text?: string;
    date: number;
  };
  callback_query?: {
    id: string;
    from: {
      id: number;
      username?: string;
      first_name?: string;
    };
    data: string;
  };
}

// Helper to send message to Telegram
async function sendTelegramMessage(botToken: string, chatId: string, text: string, replyToMessageId?: number): Promise<any> {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  
  const payload: any = {
    chat_id: chatId,
    text: text,
    parse_mode: 'Markdown'
  };

  if (replyToMessageId) {
    payload.reply_to_message_id = replyToMessageId;
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Telegram API error: ${error}`);
  }

  return response.json();
}

// Helper to generate password
function generateTempPassword(): string {
  return crypto.randomBytes(16).toString('hex');
}

export async function telegramRoutes(fastify: FastifyInstance) {
  // ═══════════════════════════════════════════════════════════════════════
  // TELEGRAM WEBHOOK (CORRIGÉ - Le bot répond!)
  // ═══════════════════════════════════════════════════════════════════════
  fastify.post<{ Body: TelegramWebhookBody }>('/telegram/webhook', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const update = request.body;
      const botToken = config.telegramBotToken;

      // ═══════════════════════════════════════════════════════════════
      // VALIDATION DU WEBHOOK (Sécurité)
      // ═══════════════════════════════════════════════════════════════
      const secretToken = request.headers['x-telegram-bot-api-secret-token'];
      if (config.telegramWebhookSecret && secretToken !== config.telegramWebhookSecret) {
        logger.warn({ ip: request.ip }, 'Invalid webhook secret');
        return reply.status(403).send({ success: false, error: 'Invalid secret' });
      }

      // ═══════════════════════════════════════════════════════════════
      // TRAITEMENT DES MESSAGES
      // ═══════════════════════════════════════════════════════════════
      if (update.message && update.message.text) {
        const telegramId = update.message.from.id.toString();
        const messageText = update.message.text;
        const chatId = update.message.chat.id.toString();
        const messageId = update.message.message_id;

        // ═══════════════════════════════════════════════════════════════
        // COMMANDE /START - Message d'accueil
        // ═══════════════════════════════════════════════════════════════
        if (messageText === '/start') {
          // Create user if doesn't exist
          let user = await prisma.user.findFirst({
            where: { telegramId }
          });

          if (!user) {
            const tempPassword = generateTempPassword();
            user = await prisma.user.create({
              data: {
                telegramId,
                telegramUsername: update.message.from.username,
                telegramFirstName: update.message.from.first_name,
                telegramLanguageCode: update.message.from.language_code,
                email: `${telegramId}@telegram.local`,
                passwordHash: tempPassword,
                isActive: true,
                isBanned: false
              }
            });
            logger.info({ userId: user.id, telegramId }, 'New user from /start');
          }

          // Send welcome message with subscription options
          const welcomeMessage = `🤖 *Bienvenue sur Telegram AI Bot!*

Je suis votre assistant IA personnel. Voici ce que je peux faire :

*Fonctionnalités :*
• 💬 *Conversation intelligente* - Discutez avec moi sur n'importe quel sujet
• 🔍 *Recherche web* - Je peux rechercher des informations pour vous
• 📚 *Mémoire contextuelle* - Je me souviens de notre conversation

*Tarification :*
• 🥉 *Promo* - 4.99€/mois
• 🥈 *Standard* - 9.99€/mois

Pour commencer, il vous suffit de m'envoyer un message!

*Commandes :*
/start - Afficher ce message d'aide
/status - Voir votre abonnement
/aide - Obtenir de l'aide`;

          await sendTelegramMessage(botToken, chatId, welcomeMessage, messageId);
          return { success: true, action: 'welcome_sent' };
        }

        // Find or create user
        let user = await prisma.user.findFirst({
          where: { telegramId }
        });

        if (!user) {
          // Create new user with temporary password
          const tempPassword = generateTempPassword();
          
          user = await prisma.user.create({
            data: {
              telegramId,
              telegramUsername: update.message.from.username,
              telegramFirstName: update.message.from.first_name,
              telegramLanguageCode: update.message.from.language_code,
              email: `${telegramId}@telegram.local`,
              password: tempPassword, // À hacher avec bcrypt en production!
              isActive: true,
              isBanned: false
            }
          });

          logger.info({ userId: user.id, telegramId }, 'New user created from Telegram');
        }

        // Save incoming message
        await prisma.message.create({
          data: {
            userId: user.id,
            role: 'USER',
            content: messageText,
            platform: 'telegram'
          }
        });

        // Update last seen
        await prisma.user.update({
          where: { id: user.id },
          data: { lastActiveAt: new Date() }
        });

        logger.info({ userId: user.id, message: messageText }, 'Message received');

        // ═══════════════════════════════════════════════════════════════
        // APPEL DE L'IA ET RÉPONSE (CORRECTION CRITIQUE!)
        // ═══════════════════════════════════════════════════════════════
        try {
          // Get conversation history for context
          const recentMessages = await prisma.message.findMany({
            where: { userId: user.id },
            orderBy: { createdAt: 'desc' },
            take: 10,
            select: { role: true, content: true }
          });

          const conversationHistory = recentMessages.reverse().map(m => ({
            role: m.role.toLowerCase() as 'user' | 'assistant',
            content: m.content
          }));

          // Prepare messages for AI (system + history)
          const aiMessages = [
            { role: 'system', content: 'You are a helpful AI assistant. Respond in French since the user is writing in French. Keep responses concise and helpful.' },
            ...conversationHistory
          ];

          // Call Ollama (local AI)
          const ollamaUrl = config.ollamaUrl || 'http://localhost:11434';
          const ollamaModel = config.ollamaModel || 'llama3';

          const aiResponse = await fetch(`${ollamaUrl}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              model: ollamaModel,
              messages: aiMessages,
              stream: false
            })
          });

          let aiText = "Désolé, une erreur s'est produite.";

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            aiText = aiData.message?.content || aiData.response || aiText;
          } else {
            logger.error({ userId: user.id }, 'Ollama request failed');
            aiText = "🤖 L'IA temporairement indisponible. Réessayez dans un instant.";
          }

          // Send response to Telegram
          await sendTelegramMessage(botToken, chatId, aiText, messageId);

          // Save assistant message
          await prisma.message.create({
            data: {
              userId: user.id,
              role: 'ASSISTANT',
              content: aiText,
              platform: 'telegram',
              aiModel: ollamaModel
            }
          });

          logger.info({ userId: user.id }, 'Response sent');

        } catch (aiError) {
          logger.error({ err: aiError, userId: user.id }, 'AI processing failed');
          
          // Send error message to user
          await sendTelegramMessage(botToken, chatId, "⚠️ Une erreur s'est produite. Veuillez réessayer.", messageId);
        }

        return { success: true, action: 'processed' };
      }

      // ═══════════════════════════════════════════════════════════════
      // TRAITEMENT DES CALLBACK QUERIES
      // ═══════════════════════════════════════════════════════════════
      if (update.callback_query) {
        const telegramId = update.callback_query.from.id.toString();
        const callbackData = update.callback_query.data;

        logger.info({ telegramId, data: callbackData }, 'Callback query received');

        // Answer callback query to remove loading state
        await fetch(`https://api.telegram.org/bot${botToken}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ callback_query_id: update.callback_query.id })
        });

        return { success: true, action: 'callback_processed' };
      }

      return { success: true };
    } catch (error) {
      logger.error({ err: error }, 'Webhook processing failed');
      return reply.status(500).send({
        success: false,
        error: 'Webhook processing failed'
      });
    }
  });

  // ═══════════════════════════════════════════════════════════════════════
  // SET WEBHOOK (Admin only)
  // ═══════════════════════════════════════════════════════════════════════
  fastify.post('/telegram/set-webhook', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { webhookUrl } = request.body as any;
      const botToken = config.telegramBotToken;

      if (!webhookUrl) {
        return reply.status(400).send({
          success: false,
          error: 'webhookUrl required'
        });
      }

      const response = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: webhookUrl,
          secret_token: config.telegramWebhookSecret
        })
      });

      const result = await response.json();

      if (result.ok) {
        logger.info({ url: webhookUrl }, 'Webhook set successfully');
        return { success: true, result };
      } else {
        return reply.status(400).send({
          success: false,
          error: result.description
        });
      }
    } catch (error) {
      logger.error({ err: error }, 'Failed to set webhook');
      return reply.status(500).send({
        success: false,
        error: 'Failed to set webhook'
      });
    }
  });

  // Get conversation history
  fastify.get('/telegram/conversations', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      
      const messages = await prisma.message.findMany({
        where: { userId: user.userId },
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: {
          id: true,
          role: true,
          content: true,
          createdAt: true,
          aiModel: true
        }
      });

      return {
        success: true,
        data: messages.reverse()
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get conversations');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get conversations'
      });
    }
  });

  // Send message to user (admin)
  fastify.post('/telegram/send', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { message, userId } = request.body as any;

      if (!message || !userId) {
        return reply.status(400).send({
          success: false,
          error: 'message and userId required'
        });
      }

      const user = await prisma.user.findUnique({
        where: { id: userId }
      });

      if (!user) {
        return reply.status(404).send({
          success: false,
          error: 'User not found'
        });
      }

      // Send via Telegram
      await sendTelegramMessage(config.telegramBotToken, user.telegramId, message);

      // Save message
      await prisma.message.create({
        data: {
          userId: userId,
          role: 'ASSISTANT',
          content: message,
          platform: 'telegram'
        }
      });

      return { success: true };
    } catch (error) {
      logger.error({ err: error }, 'Failed to send message');
      return reply.status(500).send({
        success: false,
        error: 'Failed to send message'
      });
    }
  });
}
