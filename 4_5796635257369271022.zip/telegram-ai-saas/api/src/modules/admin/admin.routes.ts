// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN - Admin Panel Routes
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';

interface StatsQuery {
  page?: number;
  limit?: number;
  active?: boolean;
}

export async function adminRoutes(fastify: FastifyInstance) {
  // Get dashboard stats
  fastify.get('/admin/stats', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const [
        totalUsers,
        activeUsers,
        totalMessages,
        messagesToday,
        totalLicenses,
        activeLicenses,
        revenue
      ] = await Promise.all([
        prisma.user.count(),
        prisma.user.count({ where: { isActive: true } }),
        prisma.message.count(),
        prisma.message.count({ where: { createdAt: { gte: today } } }),
        prisma.license.count(),
        prisma.license.count({ where: { status: 'active' } }),
        prisma.payment.aggregate({
          _sum: { amount: true },
          where: { status: 'completed' }
        })
      ]);

      return {
        success: true,
        data: {
          users: {
            total: totalUsers,
            active: activeUsers
          },
          messages: {
            total: totalMessages,
            today: messagesToday
          },
          licenses: {
            total: totalLicenses,
            active: activeLicenses
          },
          revenue: {
            total: revenue._sum.amount || 0
          }
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get admin stats');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get stats'
      });
    }
  });

  // List all users
  fastify.get<{ Querystring: StatsQuery }>('/admin/users', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { page = 1, limit = 20, active } = request.query;

      const where: any = {};
      if (active !== undefined) {
        where.isActive = active === 'true';
      }

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          skip: (page - 1) * limit,
          take: limit,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            telegramId: true,
            telegramUsername: true,
            telegramFirstName: true,
            email: true,
            plan: true,
            isActive: true,
            createdAt: true,
            lastSeenAt: true,
            _count: {
              select: { messages: true }
            }
          }
        }),
        prisma.user.count({ where })
      ]);

      return {
        success: true,
        data: {
          users,
          pagination: {
            page,
            limit,
            total,
            pages: Math.ceil(total / limit)
          }
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get users');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get users'
      });
    }
  });

  // Get user details
  fastify.get('/admin/users/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { id } = request.params as any;

      const user = await prisma.user.findUnique({
        where: { id },
        include: {
          subscription: true,
          messages: {
            orderBy: { createdAt: 'desc' },
            take: 50
          },
          payments: {
            orderBy: { createdAt: 'desc' },
            take: 10
          },
          licenses: {
            orderBy: { createdAt: 'desc' },
            take: 5
          }
        }
      });

      if (!user) {
        return reply.status(404).send({
          success: false,
          error: 'User not found'
        });
      }

      return {
        success: true,
        data: user
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get user');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get user'
      });
    }
  });

  // Toggle user active status
  fastify.patch('/admin/users/:id/toggle', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { id } = request.params as any;
      const { active } = request.body as any;

      await prisma.user.update({
        where: { id },
        data: { isActive: active }
      });

      logger.info({ userId: id, active }, 'User status toggled');

      return {
        success: true,
        message: `User ${active ? 'activated' : 'deactivated'}`
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to toggle user');
      return reply.status(500).send({
        success: false,
        error: 'Failed to toggle user'
      });
    }
  });

  // List all licenses
  fastify.get('/admin/licenses', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const licenses = await prisma.license.findMany({
        orderBy: { createdAt: 'desc' },
        take: 100
      });

      return {
        success: true,
        data: licenses
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get licenses');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get licenses'
      });
    }
  });

  // Get payments
  fastify.get('/admin/payments', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const payments = await prisma.payment.findMany({
        orderBy: { createdAt: 'desc' },
        take: 100
      });

      return {
        success: true,
        data: payments
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get payments');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get payments'
      });
    }
  });
}
