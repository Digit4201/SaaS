// ═══════════════════════════════════════════════════════════════════════════════
// LICENSE - License Management Routes (CORRIGÉ V3)
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { nanoid } from 'nanoid';
import crypto from 'crypto';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/config.js';

interface GenerateLicenseBody {
  type: 'promo' | 'standard';
  durationDays?: number;
  resellerId?: string;
}

interface ValidateLicenseBody {
  licenseKey: string;
}

function generateLicenseKey(type: string): string {
  const prefix = type === 'promo' ? 'LIC_PRO' : 'LIC_STD';
  const randomPart = nanoid(24).toUpperCase();
  return `${prefix}_${randomPart}`;
}

function signLicense(licenseKey: string): string {
  return crypto
    .createHmac('sha256', config.licenseSecret)
    .update(licenseKey)
    .digest('hex')
    .substring(0, 64);
}

export async function licenseRoutes(fastify: FastifyInstance) {
  // Generate license (admin only, but simplified for demo)
  fastify.post<{ Body: GenerateLicenseBody }>('/license/generate', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { type, durationDays = 30, resellerId } = request.body;

      const licenseKey = generateLicenseKey(type);
      const signature = signLicense(licenseKey);

      // Find plan ID based on type
      const plan = await prisma.plan.findFirst({
        where: { name: type === 'promo' ? 'Promo' : 'Standard' }
      });

      const license = await prisma.licenseKey.create({
        data: {
          key: licenseKey,
          signature,
          type,
          credits: type === 'promo' ? 100 : 500,
          durationDays,
          status: 'active',
          resellerId,
          expiresAt: new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)
        }
      });

      logger.info({ licenseId: license.id, type }, 'License generated');

      return {
        success: true,
        data: {
          licenseKey: license.key,
          signature: license.signature,
          type: license.type,
          credits: license.credits,
          durationDays: license.durationDays,
          expiresAt: license.expiresAt
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'License generation failed');
      return reply.status(500).send({
        success: false,
        error: 'License generation failed'
      });
    }
  });

  // Validate license and activate
  fastify.post<{ Body: ValidateLicenseBody }>('/license/activate', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { licenseKey } = request.body;

      // Find license
      const license = await prisma.licenseKey.findUnique({
        where: { key: licenseKey }
      });

      if (!license) {
        return reply.status(400).send({
          success: false,
          error: 'Invalid license key'
        });
      }

      // Check if already used
      if (license.usedBy) {
        return reply.status(400).send({
          success: false,
          error: 'License already activated',
          usedBy: license.usedBy
        });
      }

      // Check expiration
      if (new Date(license.expiresAt) < new Date()) {
        return reply.status(400).send({
          success: false,
          error: 'License expired'
        });
      }

      // Find plan
      const plan = await prisma.plan.findFirst({
        where: { name: license.type === 'promo' ? 'Promo' : 'Standard' }
      });

      if (!plan) {
        return reply.status(400).send({
          success: false,
          error: 'Plan not found'
        });
      }

      // Activate license
      const updatedLicense = await prisma.licenseKey.update({
        where: { id: license.id },
        data: {
          status: 'used',
          usedBy: user.userId,
          usedAt: new Date()
        }
      });

      // Create activation record
      await prisma.licenseActivation.create({
        data: {
          licenseId: license.id,
          userId: user.userId
        }
      });

      // Create or update subscription using planId
      await prisma.subscription.upsert({
        where: { userId: user.userId },
        update: {
          planId: plan.id,
          status: 'active',
          currentPeriodStart: new Date(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        },
        create: {
          userId: user.userId,
          planId: plan.id,
          status: 'active',
          currentPeriodStart: new Date(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        }
      });

      logger.info({ userId: user.userId, licenseId: license.id }, 'License activated');

      return {
        success: true,
        data: {
          plan: plan.displayName,
          credits: plan.monthlyLimit,
          expiresAt: license.expiresAt
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'License activation failed');
      return reply.status(500).send({
        success: false,
        error: 'License activation failed'
      });
    }
  });

  // Check license status
  fastify.get('/license/status', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const subscription = await prisma.subscription.findUnique({
        where: { userId: user.userId },
        include: { plan: true }
      });

      if (!subscription) {
        return {
          success: true,
          data: {
            hasLicense: false,
            plan: 'free'
          }
        };
      }

      const activation = await prisma.licenseActivation.findFirst({
        where: { userId: user.userId },
        include: { license: true },
        orderBy: { activatedAt: 'desc' }
      });

      return {
        success: true,
        data: {
          hasLicense: true,
          plan: subscription.plan.displayName,
          creditsRemaining: subscription.plan.monthlyLimit,
          creditsTotal: subscription.plan.monthlyLimit,
          licenseExpiresAt: activation?.license.expiresAt,
          resetDate: subscription.currentPeriodEnd
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'License status check failed');
      return reply.status(500).send({
        success: false,
        error: 'Failed to check license status'
      });
    }
  });

  // Verify license (public endpoint)
  fastify.post('/license/verify', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { licenseKey } = request.body as any;

      const license = await prisma.licenseKey.findUnique({
        where: { key: licenseKey }
      });

      if (!license) {
        return reply.status(400).send({
          success: false,
          valid: false,
          error: 'Invalid license key'
        });
      }

      // Verify signature
      const expectedSignature = signLicense(licenseKey);
      const signatureValid = license.signature === expectedSignature;

      const valid = 
        license.status === 'active' &&
        new Date(license.expiresAt) > new Date() &&
        !license.usedBy &&
        signatureValid;

      return {
        success: true,
        data: {
          valid,
          type: license.type,
          credits: license.credits,
          expiresAt: license.expiresAt,
          used: !!license.usedBy
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'License verification failed');
      return reply.status(500).send({
        success: false,
        error: 'License verification failed'
      });
    }
  });
}
