// ═══════════════════════════════════════════════════════════════════════════════
// RGPD - GDPR/Privacy Routes
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';

export async function rgpdRoutes(fastify: FastifyInstance) {
  // Request data export
  fastify.post('/rgpd/export', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const userData = await prisma.user.findUnique({
        where: { id: user.userId },
        include: {
          messages: true,
          subscription: true,
          payments: true,
          licenses: true,
          usageRecords: true
        }
      });

      // Remove sensitive data
      const exportData = {
        ...userData,
        password: undefined,
        email: userData?.email // Keep email for identification
      };

      return {
        success: true,
        data: exportData
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to export data');
      return reply.status(500).send({
        success: false,
        error: 'Failed to export data'
      });
    }
  });

  // Request account deletion
  fastify.post('/rgpd/delete', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { confirmEmail } = request.body as any;

      const userData = await prisma.user.findUnique({
        where: { id: user.userId }
      });

      if (userData?.email !== confirmEmail) {
        return reply.status(400).send({
          success: false,
          error: 'Email confirmation does not match'
        });
      }

      // Soft delete - anonymize data
      await prisma.user.update({
        where: { id: user.userId },
        data: {
          email: `deleted_${Date.now()}@deleted.local`,
          telegramId: `deleted_${Date.now()}`,
          telegramUsername: null,
          telegramFirstName: null,
          isActive: false,
          deletionRequestedAt: new Date()
        }
      });

      logger.info({ userId: user.userId }, 'Account deletion requested');

      return {
        success: true,
        message: 'Account deletion requested. Data will be removed within 30 days.'
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to delete account');
      return reply.status(500).send({
        success: false,
        error: 'Failed to delete account'
      });
    }
  });

  // Get privacy settings
  fastify.get('/rgpd/settings', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const userData = await prisma.user.findUnique({
        where: { id: user.userId },
        select: {
          id: true,
          isActive: true,
          createdAt: true,
          lastSeenAt: true,
          deletionRequestedAt: true
        }
      });

      return {
        success: true,
        data: {
          accountStatus: userData?.isActive ? 'active' : 'deactivated',
          createdAt: userData?.createdAt,
          lastActive: userData?.lastSeenAt,
          deletionRequested: !!userData?.deletionRequestedAt
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get privacy settings');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get privacy settings'
      });
    }
  });
}
