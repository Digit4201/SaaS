// ═══════════════════════════════════════════════════════════════════════════════
// BILLING - Payment Routes (CORRIGÉ)
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/config.js';

export async function billingRoutes(fastify: FastifyInstance) {
  // ═══════════════════════════════════════════════════════════════════════
  // PLANS (Public)
  // ═══════════════════════════════════════════════════════════════════════
  fastify.get('/plans', async (request: FastifyRequest, reply: FastifyReply) => {
    return {
      success: true,
      data: {
        promo: {
          id: 'promo',
          name: 'Promo',
          price: config.pricing.promo.monthlyPrice,
          yearlyPrice: config.pricing.promo.yearlyPrice,
          features: config.pricing.promo.features
        },
        standard: {
          id: 'standard',
          name: 'Standard',
          price: config.pricing.standard.monthlyPrice,
          yearlyPrice: config.pricing.standard.yearlyPrice,
          features: config.pricing.standard.features
        }
      }
    };
  });

  // ═══════════════════════════════════════════════════════════════════════
  // USER BILLING (Auth required)
  // ═══════════════════════════════════════════════════════════════════════
  
  // Get user's subscription
  fastify.get('/subscription', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const subscription = await prisma.subscription.findUnique({
        where: { userId: user.userId },
        include: {
          plan: true
        }
      });

      return {
        success: true,
        data: subscription
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get subscription');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get subscription'
      });
    }
  });

  // Get user payment history (CORRIGÉ - utilise invoices au lieu de payments)
  fastify.get('/payments', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      // Use invoices instead of non-existent payments model
      const payments = await prisma.invoice.findMany({
        where: { userId: user.userId },
        orderBy: { createdAt: 'desc' },
        take: 20
      });

      return {
        success: true,
        data: payments
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get payments');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get payments'
      });
    }
  });

  // Get usage stats
  fastify.get('/usage', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;

      const subscription = await prisma.subscription.findUnique({
        where: { userId: user.userId }
      });

      if (!subscription) {
        return {
          success: true,
          data: {
            plan: 'free',
            used: 0,
            limit: 0,
            percentage: 0
          }
        };
      }

      return {
        success: true,
        data: {
          plan: subscription.status,
          used: 0,
          limit: 0,
          percentage: 0,
          status: subscription.status,
          renewDate: subscription.currentPeriodEnd
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get usage');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get usage'
      });
    }
  });

  // Create checkout session (Placeholder)
  fastify.post('/checkout', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { planId } = request.body as any;

      // Create placeholder checkout URL
      // TODO: Implement real Lemon Squeezy integration
      return {
        success: true,
        data: {
          checkoutUrl: `https://checkout.lemonsqueezy.com/checkout/${planId}?user=${user.userId}`,
          checkoutId: `cs_${Date.now()}`,
          message: 'Checkout integration pending - configure Lemon Squeezy API keys'
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to create checkout');
      return reply.status(500).send({
        success: false,
        error: 'Failed to create checkout'
      });
    }
  });

  // ═══════════════════════════════════════════════════════════════════════
  // ADMIN BILLING (Admin only - prefixé /billing/admin/)
  // ═══════════════════════════════════════════════════════════════════════
  
  // Get all payments
  fastify.get('/admin/payments', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { status, limit = 50 } = request.query as any;

      const payments = await prisma.invoice.findMany({
        where: status ? { status } : undefined,
        orderBy: { createdAt: 'desc' },
        take: parseInt(limit)
      });

      return {
        success: true,
        data: payments
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get payments');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get payments'
      });
    }
  });

  // Get revenue stats
  fastify.get('/admin/stats', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const now = new Date();
      const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      // Count active subscriptions
      const activeSubscriptions = await prisma.subscription.count({
        where: { status: 'active' }
      });

      // Get invoices this month
      const monthlyInvoices = await prisma.invoice.findMany({
        where: {
          createdAt: { gte: firstOfMonth },
          status: 'paid'
        }
      });

      const monthlyRevenue = monthlyInvoices.reduce((sum, inv) => sum + inv.amountCents, 0) / 100;

      return {
        success: true,
        data: {
          activeSubscriptions,
          monthlyRevenue,
          monthlyInvoices: monthlyInvoices.length
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get stats');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get stats'
      });
    }
  });
}
