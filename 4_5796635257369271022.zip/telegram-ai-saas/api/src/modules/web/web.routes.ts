// ═══════════════════════════════════════════════════════════════════════════════
// WEB - Web Browsing Routes
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/config.js';

interface SearchRequest {
  query: string;
  count?: number;
}

interface FetchRequest {
  url: string;
  extractMode?: 'text' | 'markdown';
  maxChars?: number;
}

export async function webRoutes(fastify: FastifyInstance) {
  // Web search using Brave API
  fastify.post<{ Body: SearchRequest }>('/web/search', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { query, count = 10 } = request.body;

      if (!query) {
        return reply.status(400).send({
          success: false,
          error: 'Query is required'
        });
      }

      // Check if user has their own Brave API key
      const userApiKey = await prisma.userApiKey.findUnique({
        where: { user_id_platform: { user_id: user.userId, platform: 'brave' } }
      });

      const braveApiKey = userApiKey ? userApiKey.apiKey : config.braveApiKey;

      if (!braveApiKey) {
        return reply.status(400).send({
          success: false,
          error: 'Brave API key not configured'
        });
      }

      // Perform search (simplified - would use actual Brave API in production)
      const results = await performBraveSearch(query, count, braveApiKey);

      // Log usage
      await prisma.usageRecord.create({
        data: {
          userId: user.userId,
          recordType: 'WEB_SEARCH',
          amount: 1
        }
      });

      return {
        success: true,
        data: {
          query,
          results,
          count: results.length
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Web search failed');
      return reply.status(500).send({
        success: false,
        error: 'Web search failed'
      });
    }
  });

  // Fetch page content
  fastify.post<{ Body: FetchRequest }>('/web/fetch', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { url, extractMode = 'text', maxChars = 10000 } = request.body;

      if (!url) {
        return reply.status(400).send({
          success: false,
          error: 'URL is required'
        });
      }

      // Fetch and extract content (simplified)
      const content = await fetchWebPage(url, extractMode, maxChars);

      // Log usage
      await prisma.usageRecord.create({
        data: {
          userId: user.userId,
          recordType: 'WEB_FETCH',
          amount: 1
        }
      });

      return {
        success: true,
        data: {
          url,
          content,
          length: content.length
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Web fetch failed');
      return reply.status(500).send({
        success: false,
        error: 'Web fetch failed'
      });
    }
  });
}

// Helper functions
async function performBraveSearch(query: string, count: number, apiKey: string) {
  // In production, this would use the actual Brave Search API
  // For now, return mock results
  return [
    {
      title: `Result for: ${query}`,
      url: `https://example.com/1`,
      description: 'This is a search result description',
      siteName: 'Example Site'
    },
    {
      title: `Another result for: ${query}`,
      url: `https://example.com/2`,
      description: 'Another search result description',
      siteName: 'Example Site 2'
    }
  ].slice(0, count);
}

async function fetchWebPage(url: string, extractMode: string, maxChars: number) {
  // In production, this would fetch and parse the actual page
  // For now, return mock content
  return `Content from ${url}. This is a placeholder for the actual web page content that would be fetched and extracted.`;
}
