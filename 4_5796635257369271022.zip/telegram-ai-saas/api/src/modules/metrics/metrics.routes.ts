// ═══════════════════════════════════════════════════════════════════════════════
// PROMETHEUS METRICS - API Monitoring
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance } from 'fastify';
import { prisma } from '../config/database.js';

// ═══════════════════════════════════════════════════════════════════════════════
// Custom Metrics Store
// ═══════════════════════════════════════════════════════════════════════════════

const metrics = {
  httpRequestsTotal: new Map<string, number>(),
  httpRequestDuration: new Map<string, number[]>(),
  aiRequestsTotal: new Map<string, number>(),
  activeUsers: new Map<string, number>(),
  messagesTotal: new Map<string, number>(),
  revenueTotal: 0,
  licensesGenerated: 0,
};

// ═══════════════════════════════════════════════════════════════════════════════
// Metrics Routes
// ═══════════════════════════════════════════════════════════════════════════════

export async function metricsRoutes(fastify: FastifyInstance) {
  // Prometheus metrics format
  fastify.get('/metrics', async (request, reply) => {
    try {
      // Get stats from database
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      
      // Count users
      const totalUsers = await prisma.user.count();
      const activeUsers = await prisma.user.count({
        where: { isActive: true }
      });
      
      // Count messages today
      const messagesToday = await prisma.message.count({
        where: { createdAt: { gte: today } }
      });
      
      // Count subscriptions
      const activeSubscriptions = await prisma.subscription.count({
        where: { status: 'active' }
      });
      
      // Calculate revenue (from paid invoices)
      const paidInvoices = await prisma.invoice.findMany({
        where: { status: 'paid' }
      });
      const totalRevenue = paidInvoices.reduce((sum, inv) => sum + inv.amountCents, 0) / 100;

      // Build Prometheus output
      const output = [
        '# HELP http_requests_total Total number of HTTP requests',
        '# TYPE http_requests_total counter',
        ...Array.from(metrics.httpRequestsTotal.entries()).map(
          (([method, count]) => `http_requests_total{method="${method}"} ${count}`)
        ),
        '',
        '# HELP http_request_duration_seconds HTTP request duration in seconds',
        '# TYPE http_request_duration_seconds histogram',
        `http_request_duration_seconds_bucket{le="0.005"} ${metrics.httpRequestDuration.get('0.005')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.01"} ${metrics.httpRequestDuration.get('0.01')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.025"} ${metrics.httpRequestDuration.get('0.025')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.05"} ${metrics.httpRequestDuration.get('0.05')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.1"} ${metrics.httpRequestDuration.get('0.1')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.25"} ${metrics.httpRequestDuration.get('0.25')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="0.5"} ${metrics.httpRequestDuration.get('0.5')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="1"} ${metrics.httpRequestDuration.get('1')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="2.5"} ${metrics.httpRequestDuration.get('2.5')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="5"} ${metrics.httpRequestDuration.get('5')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="10"} ${metrics.httpRequestDuration.get('10')?.length || 0}`,
        `http_request_duration_seconds_bucket{le="+Inf"} ${messagesToday}`,
        `http_request_duration_seconds_sum ${metrics.httpRequestDuration.get('sum') || 0}`,
        `http_request_duration_seconds_count ${messagesToday}`,
        '',
        '# HELP ai_requests_total Total number of AI requests',
        '# TYPE ai_requests_total counter',
        `ai_requests_total ${metrics.aiRequestsTotal.get('total') || 0}`,
        '',
        '# HELP active_users Total active users',
        '# TYPE active_users gauge',
        `active_users ${activeUsers}`,
        '',
        '# HELP total_users Total registered users',
        '# TYPE total_users gauge',
        `total_users ${totalUsers}`,
        '',
        '# HELP messages_today Messages received today',
        '# TYPE messages_today gauge',
        `messages_today ${messagesToday}`,
        '',
        '# HELP active_subscriptions Total active subscriptions',
        '# TYPE active_subscriptions gauge',
        `active_subscriptions ${activeSubscriptions}`,
        '',
        '# HELP revenue_total_total Total revenue in EUR',
        '# TYPE revenue_total_total counter',
        `revenue_total ${totalRevenue.toFixed(2)}`,
        '',
        '# HELP licenses_generated_total Total licenses generated',
        '# TYPE licenses_generated_total counter',
        `licenses_generated_total ${metrics.licensesGenerated}`,
        '',
        '# HELP process_uptime_seconds Process uptime in seconds',
        '# TYPE process_uptime_seconds gauge',
        `process_uptime_seconds ${Math.floor(process.uptime())}`,
        '',
        '# HELP process_memory_bytes Process memory in bytes',
        '# TYPE process_memory_bytes gauge',
        `process_memory_bytes ${process.memoryUsage().heapUsed}`,
        '',
        '# HELP process_cpu_percent Process CPU percentage',
        '# TYPE process_cpu_percent gauge',
        `process_cpu_percent ${process.cpuUsage().user}`,
      ].join('\n');

      reply.header('Content-Type', 'text/plain');
      return output;
    } catch (error) {
      request.log.error({ err: error }, 'Failed to generate metrics');
      reply.status(500);
      return '# Error generating metrics';
    }
  });

  // Health check (simple)
  fastify.get('/health', async (request, reply) => {
    try {
      // Test database connection
      await prisma.$queryRaw`SELECT 1`;
      
      return {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
      };
    } catch (error) {
      reply.status(503);
      return {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: 'Database connection failed'
      };
    }
  });

  // Readiness check
  fastify.get('/ready', async (request, reply) => {
    return { ready: true };
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// Middleware for Recording Metrics
// ═══════════════════════════════════════════════════════════════════════════════

export function recordRequestMetrics(method: string, duration: number) {
  // Count request
  const current = metrics.httpRequestsTotal.get(method) || 0;
  metrics.httpRequestsTotal.set(method, current + 1);
  
  // Record duration bucket
  const bucket = duration < 0.005 ? '0.005' 
    : duration < 0.01 ? '0.01'
    : duration < 0.025 ? '0.025'
    : duration < 0.05 ? '0.05'
    : duration < 0.1 ? '0.1'
    : duration < 0.25 ? '0.25'
    : duration < 0.5 ? '0.5'
    : duration < 1 ? '1'
    : duration < 2.5 ? '2.5'
    : duration < 5 ? '5'
    : '10';
    
  const bucketDurations = metrics.httpRequestDuration.get(bucket) || [];
  bucketDurations.push(duration);
  metrics.httpRequestDuration.set(bucket, bucketDurations);
}

export function recordAIMetrics() {
  const current = metrics.aiRequestsTotal.get('total') || 0;
  metrics.aiRequestsTotal.set('total', current + 1);
}

export function incrementLicenses() {
  metrics.licensesGenerated++;
}
