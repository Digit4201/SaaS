// ═══════════════════════════════════════════════════════════════════════════════
// HEALTH - Health Check Routes
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';

export async function healthRoutes(fastify: FastifyInstance) {
  // Basic health check
  fastify.get('/health', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      // Check database connection
      await prisma.$queryRaw`SELECT 1`;
      
      return {
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        environment: process.env.NODE_ENV || 'development'
      };
    } catch (error) {
      return reply.status(503).send({
        success: false,
        status: 'unhealthy',
        error: 'Database connection failed'
      });
    }
  });

  // Readiness check
  fastify.get('/ready', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      await prisma.$queryRaw`SELECT 1`;
      
      return {
        success: true,
        ready: true,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return reply.status(503).send({
        success: false,
        ready: false,
        error: 'Service not ready'
      });
    }
  });

  // Liveness check
  fastify.get('/live', async (request: FastifyRequest, reply: FastifyReply) => {
    return {
      success: true,
      live: true,
      timestamp: new Date().toISOString()
    };
  });
}
