// ═══════════════════════════════════════════════════════════════════════════════
// AI - Routes for Ollama and OpenAI
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { prisma } from '../../config/database.js';
import { logger } from '../../config/logger.js';
import { config } from '../../config/config.js';
import { ollamaService } from './ollama.service.js';

interface ChatRequest {
  message: string;
  model?: string;
  systemPrompt?: string;
}

export async function aiRoutes(fastify: FastifyInstance) {
  // Chat completion
  fastify.post<{ Body: ChatRequest }>('/ai/chat', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const user = (request as any).user;
      const { message, model, systemPrompt } = request.body;

      if (!message) {
        return reply.status(400).send({
          success: false,
          error: 'Message is required'
        });
      }

      // Check credits
      const subscription = await prisma.subscription.findUnique({
        where: { userId: user.userId }
      });

      if (!subscription) {
        return reply.status(403).send({
          success: false,
          error: 'No subscription found'
        });
      }

      const remainingCredits = subscription.monthlyCredits - subscription.creditsUsed;
      if (remainingCredits <= 0) {
        return reply.status(403).send({
          success: false,
          error: 'No credits remaining',
          code: 'CREDITS_EXHAUSTED'
        });
      }

      // Use Ollama (local AI) by default
      const response = await ollamaService.chat(message, {
        system: systemPrompt,
        model: model || config.ollamaModel
      });

      // Save message
      await prisma.message.create({
        data: {
          userId: user.userId,
          content: message,
          aiResponse: response.response,
          direction: 'incoming',
          platform: 'telegram'
        }
      });

      // Update credits (rough estimate: 1 message = 10 credits)
      const creditsUsed = Math.ceil(message.length / 10);
      await prisma.subscription.update({
        where: { id: subscription.id },
        data: {
          creditsUsed: { increment: creditsUsed }
        }
      });

      return {
        success: true,
        data: {
          response: response.response,
          creditsUsed,
          creditsRemaining: remainingCredits - creditsUsed
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'AI chat failed');
      return reply.status(500).send({
        success: false,
        error: 'AI chat failed'
      });
    }
  });

  // Get available models
  fastify.get('/ai/models', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const models = await ollamaService.listModels();
      return {
        success: true,
        data: {
          local: models,
          default: config.ollamaModel
        }
      };
    } catch (error) {
      logger.error({ err: error }, 'Failed to get models');
      return reply.status(500).send({
        success: false,
        error: 'Failed to get models'
      });
    }
  });

  // Stream chat (WebSocket)
  fastify.get('/ai/stream', { websocket: true }, async (connection, req: FastifyRequest) => {
    try {
      const user = (req as any).user;
      
      connection.socket.on('message', async (data) => {
        try {
          const message = data.toString();
          
          const subscription = await prisma.subscription.findUnique({
            where: { userId: user.userId }
          });

          if (!subscription || subscription.creditsUsed >= subscription.monthlyCredits) {
            connection.socket.send(JSON.stringify({
              type: 'error',
              data: 'No credits remaining'
            }));
            return;
          }

          const stream = await ollamaService.stream(message);
          
          for await (const chunk of stream) {
            connection.socket.send(JSON.stringify({
              type: 'chunk',
              data: chunk
            }));
          }

          connection.socket.send(JSON.stringify({
            type: 'done',
            data: 'Stream completed'
          }));
        } catch (error) {
          connection.socket.send(JSON.stringify({
            type: 'error',
            data: 'Stream failed'
          }));
        }
      });
    } catch (error) {
      logger.error({ err: error }, 'WebSocket error');
    }
  });
}
