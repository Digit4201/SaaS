// ═══════════════════════════════════════════════════════════════════════════════
// AI - Ollama Service (Local AI)
// ═══════════════════════════════════════════════════════════════════════════════

import { config } from '../config/config.js';

interface ChatOptions {
  system?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

interface ChatResponse {
  response: string;
  model: string;
  tokens: number;
}

interface StreamChunk {
  chunk: string;
  done: boolean;
}

class OllamaService {
  private baseUrl: string;

  constructor() {
    this.baseUrl = config.ollamaUrl;
  }

  async chat(message: string, options: ChatOptions = {}): Promise<ChatResponse> {
    const model = options.model || config.ollamaModel;
    
    const body: any = {
      model,
      prompt: message,
      stream: false,
      options: {
        temperature: options.temperature || 0.7,
        num_predict: options.maxTokens || 2048
      }
    };

    if (options.system) {
      body.system = options.system;
    }

    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`Ollama error: ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        response: data.response,
        model: data.model || model,
        tokens: data.eval_count || 0
      };
    } catch (error) {
      logger.error({ err: error }, 'Ollama chat failed');
      throw error;
    }
  }

  async *stream(message: string, options: ChatOptions = {}): AsyncGenerator<StreamChunk> {
    const model = options.model || config.ollamaModel;
    
    const body = {
      model,
      prompt: message,
      stream: true,
      options: {
        temperature: options.temperature || 0.7,
        num_predict: options.maxTokens || 2048
      }
    };

    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`Ollama error: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      if (!reader) return;

      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value);
        
        try {
          const lines = chunk.split('\n').filter(Boolean);
          for (const line of lines) {
            const data = JSON.parse(line);
            yield {
              chunk: data.response || '',
              done: data.done || false
            };
            
            if (data.done) return;
          }
        } catch (e) {
          // Skip invalid JSON lines
        }
      }
    } catch (error) {
      logger.error({ err: error }, 'Ollama stream failed');
      throw error;
    }
  }

  async listModels(): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      
      if (!response.ok) {
        return [config.ollamaModel]; // Return default if error
      }

      const data = await response.json();
      return (data.models || []).map((m: any) => m.name);
    } catch (error) {
      logger.warn({ err: error }, 'Failed to list Ollama models');
      return [config.ollamaModel];
    }
  }

  async pullModel(modelName: string): Promise<void> {
    try {
      const response = await fetch(`${this.baseUrl}/api/pull`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: modelName })
      });

      if (!response.ok) {
        throw new Error(`Failed to pull model: ${response.statusText}`);
      }
    } catch (error) {
      logger.error({ err: error }, 'Failed to pull model');
      throw error;
    }
  }
}

import { logger } from '../config/logger.js';

export const ollamaService = new OllamaService();
export default ollamaService;
