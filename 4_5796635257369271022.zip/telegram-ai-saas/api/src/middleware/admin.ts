// ═══════════════════════════════════════════════════════════════════════════════
// MIDDLEWARE - Admin Authorization
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyRequest, FastifyReply } from 'fastify';

export async function adminMiddleware(request: FastifyRequest, reply: FastifyReply) {
  try {
    const user = (request as any).user;
    
    if (!user) {
      return reply.status(401).send({
        success: false,
        error: 'Authentication required'
      });
    }

    if (user.role !== 'admin') {
      return reply.status(403).send({
        success: false,
        error: 'Admin access required'
      });
    }

  } catch (error) {
    return reply.status(500).send({
      success: false,
      error: 'Authorization check failed'
    });
  }
}

export default adminMiddleware;
