// ═══════════════════════════════════════════════════════════════════════════════
// MIDDLEWARE - Authentication
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyRequest, FastifyReply } from 'fastify';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/database.js';
import { config } from '../config/config.js';

export async function authMiddleware(request: FastifyRequest, reply: FastifyReply) {
  try {
    const authHeader = request.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return reply.status(401).send({
        success: false,
        error: 'Authentication required'
      });
    }

    const token = authHeader.substring(7);
    
    const decoded = jwt.verify(token, config.jwtSecret) as {
      userId: string;
      role: string;
    };

    // Verify user exists and is active
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId }
    });

    if (!user) {
      return reply.status(401).send({
        success: false,
        error: 'User not found'
      });
    }

    if (!user.isActive) {
      return reply.status(403).send({
        success: false,
        error: 'Account is disabled'
      });
    }

    // Attach user to request
    (request as any).user = {
      userId: user.id,
      role: user.role,
      plan: user.plan,
      telegramId: user.telegramId
    };

  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      return reply.status(401).send({
        success: false,
        error: 'Token expired'
      });
    }
    
    return reply.status(401).send({
      success: false,
      error: 'Invalid token'
    });
  }
}

export default authMiddleware;
