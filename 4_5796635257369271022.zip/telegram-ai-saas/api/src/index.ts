// ═══════════════════════════════════════════════════════════════════════════════
// TELEGRAM AI SAAS - Main Entry Point (CORRIGÉ)
// ═══════════════════════════════════════════════════════════════════════════════

import 'dotenv/config';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import formbody from '@fastify/formbody';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import websocket from '@fastify/websocket';

import { config } from './config/config.js';
import { logger } from './config/logger.js';
import { prisma } from './config/database.js';

// Routes
import { healthRoutes } from './modules/health/health.routes.js';
import { authRoutes } from './modules/auth/auth.routes.js';
import { telegramRoutes } from './modules/telegram/telegram.routes.js';
import { billingRoutes } from './modules/billing/billing.routes.js';
import { aiRoutes } from './modules/ai/ai.routes.js';
import { licenseRoutes } from './modules/license/license.routes.js';
import { webRoutes } from './modules/web/web.routes.js';
import { adminRoutes } from './modules/admin/admin.routes.js';
import { usageRoutes } from './modules/usage/usage.routes.js';
import { rgpdRoutes } from './modules/rgpd/rgpd.routes.js';

// Middleware
import { authMiddleware } from './middleware/auth.js';
import { adminMiddleware } from './middleware/admin.js';

// ═══════════════════════════════════════════════════════════════════════════════

async function buildApp() {
  const fastify = Fastify({
    logger: {
      level: config.logLevel,
      transport: config.isDev ? {
        target: 'pino-pretty',
        options: { colorize: true }
      } : undefined
    }
  });

  // Security plugins
  await fastify.register(helmet, {
    contentSecurityPolicy: false
  });
  
  await fastify.register(cors, {
    origin: config.corsOrigins,
    credentials: true
  });

  // Rate limiting
  await fastify.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
    keyGenerator: (request) => request.ip
  });

  // WebSocket support
  await fastify.register(websocket);

  // Form body parsing
  await fastify.register(formbody);

  // ═══════════════════════════════════════════════════════════════════════
  // PUBLIC ROUTES (No auth required)
  // ═══════════════════════════════════════════════════════════════════════
  await fastify.register(healthRoutes);
  await fastify.register(authRoutes);     // Register/Login
  await fastify.register(licenseRoutes); // License activation

  // ═══════════════════════════════════════════════════════════════════════
  // PROTECTED ROUTES (Auth required - All logged-in users)
  // ═══════════════════════════════════════════════════════════════════════
  await fastify.addHook('preHandler', authMiddleware);
  
  await fastify.register(telegramRoutes); // User's conversations
  await fastify.register(aiRoutes);       // AI chat
  await fastify.register(webRoutes);      // Web search/fetch
  await fastify.register(usageRoutes);    // Usage history
  
  // Billing - User can see their own subscription (CORRIGÉ!)
  await fastify.register(billingRoutes, { prefix: '/billing/user' });
  
  // RGPD - User data management
  await fastify.register(rgpdRoutes);

  // ═══════════════════════════════════════════════════════════════════════
  // ADMIN ROUTES (Auth + Admin role required)
  // ═══════════════════════════════════════════════════════════════════════
  await fastify.addHook('preHandler', adminMiddleware);
  
  // Admin billing management
  await fastify.register(billingRoutes, { prefix: '/billing/admin' });
  
  // Full admin dashboard
  await fastify.register(adminRoutes);

  // ═══════════════════════════════════════════════════════════════════════
  // ERROR HANDLER
  // ═══════════════════════════════════════════════════════════════════════
  fastify.setErrorHandler((error, request, reply) => {
    logger.error({ err: error, requestId: request.id }, 'Request error');
    
    reply.status(error.statusCode || 500).send({
      success: false,
      error: config.isDev ? error.message : 'Internal Server Error'
    });
  });

  return fastify;
}

// ═══════════════════════════════════════════════════════════════════════════════

async function start() {
  try {
    // Test database connection
    await prisma.$connect();
    logger.info('✅ Database connected');

    // Build and start server
    const fastify = await buildApp();
    
    await fastify.listen({
      host: config.host,
      port: config.port
    });

    logger.info(`
╔════════════════════════════════════════════════════════════╗
║  🚀 Telegram AI SaaS API Started (CORRIGÉ)               ║
║                                                            ║
║  URL: http://${config.host}:${config.port}                        ║
║  Health: http://${config.host}:${config.port}/health                  ║
║  Environment: ${config.nodeEnv}                                  ║
╚════════════════════════════════════════════════════════════╝
    `);

    // Graceful shutdown
    const signals = ['SIGINT', 'SIGTERM'];
    signals.forEach(signal => {
      process.on(signal, async () => {
        logger.info(`Received ${signal}, shutting down...`);
        await fastify.close();
        await prisma.$disconnect();
        process.exit(0);
      });
    });

  } catch (error) {
    logger.error({ err: error }, 'Failed to start server');
    process.exit(1);
  }
}

// Start the server
start();

export { buildApp };
