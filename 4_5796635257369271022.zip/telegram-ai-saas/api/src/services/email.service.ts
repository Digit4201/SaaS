// ═══════════════════════════════════════════════════════════════════════════════
// EMAIL NOTIFICATIONS - SendGrid/Postmark Integration
// ═══════════════════════════════════════════════════════════════════════════════

import { FastifyInstance } from 'fastify';
import { config } from '../config/config.js';
import { logger } from '../config/logger.js';

// ═══════════════════════════════════════════════════════════════════════════════
// Email Provider Interface
// ═══════════════════════════════════════════════════════════════════════════════

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

interface EmailProvider {
  send(options: EmailOptions): Promise<{ success: boolean; messageId?: string }>;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SendGrid Implementation
// ═══════════════════════════════════════════════════════════════════════════════

class SendGridProvider implements EmailProvider {
  private apiKey: string;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.apiKey = process.env.SENDGRID_API_KEY || '';
    this.fromEmail = process.env.EMAIL_FROM || 'noreply@telegram-ai.bot';
    this.fromName = process.env.EMAIL_FROM_NAME || 'Telegram AI Bot';
  }

  async send(options: EmailOptions): Promise<{ success: boolean; messageId?: string }> {
    if (!this.apiKey) {
      logger.warn('SendGrid API key not configured');
      return { success: false };
    }

    try {
      const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          personalizations: [{
            to: [{ email: options.to }],
            dynamic_template_data: {
              subject: options.subject,
              content: options.html
            }
          }],
          from: {
            email: this.fromEmail,
            name: this.fromName
          },
          subject: options.subject,
          content: [
            { type: 'text/plain', value: options.text || options.html.replace(/<[^>]*>/g, '') },
            { type: 'text/html', value: options.html }
          ]
        })
      });

      if (response.ok) {
        const messageId = response.headers.get('x-message-id') || undefined;
        logger.info({ to: options.to, subject: options.subject }, 'Email sent via SendGrid');
        return { success: true, messageId };
      }

      const error = await response.text();
      logger.error({ error }, 'SendGrid send failed');
      return { success: false };
    } catch (error) {
      logger.error({ err: error }, 'SendGrid error');
      return { success: false };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Postmark Implementation
// ═══════════════════════════════════════════════════════════════════════════════

class PostmarkProvider implements EmailProvider {
  private serverToken: string;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.serverToken = process.env.POSTMARK_SERVER_TOKEN || '';
    this.fromEmail = process.env.EMAIL_FROM || 'noreply@telegram-ai.bot';
    this.fromName = process.env.EMAIL_FROM_NAME || 'Telegram AI Bot';
  }

  async send(options: EmailOptions): Promise<{ success: boolean; messageId?: string }> {
    if (!this.serverToken) {
      logger.warn('Postmark server token not configured');
      return { success: false };
    }

    try {
      const response = await fetch('https://api.postmarkapp.com/email', {
        method: 'POST',
        headers: {
          'X-Postmark-Server-Token': this.serverToken,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          From: `${this.fromName} <${this.fromEmail}>`,
          To: options.to,
          Subject: options.subject,
          HtmlBody: options.html,
          TextBody: options.text || options.html.replace(/<[^>]*>/g, ''),
          MessageStream: 'outbound'
        })
      });

      if (response.ok) {
        const data = await response.json();
        logger.info({ to: options.to, subject: options.subject }, 'Email sent via Postmark');
        return { success: true, messageId: data.MessageID?.toString() };
      }

      const error = await response.json();
      logger.error({ error }, 'Postmark send failed');
      return { success: false };
    } catch (error) {
      logger.error({ err: error }, 'Postmark error');
      return { success: false };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Email Factory
// ═══════════════════════════════════════════════════════════════════════════════

function getEmailProvider(): EmailProvider {
  const provider = process.env.EMAIL_PROVIDER || 'sendgrid';
  
  switch (provider) {
    case 'postmark':
      return new PostmarkProvider();
    case 'sendgrid':
    default:
      return new SendGridProvider();
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Email Templates
// ═══════════════════════════════════════════════════════════════════════════════

const templates = {
  welcome: (name: string) => ({
    subject: '🎉 Bienvenue sur Telegram AI Bot!',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; color: #666; font-size: 12px; margin-top: 20px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🤖 Bienvenue, ${name}!</h1>
          </div>
          <div class="content">
            <p>Merci de rejoindre Telegram AI Bot!</p>
            <p>Votre assistant IA personnel est prêt à vous aider.</p>
            <a href="https://t.me/${process.env.TELEGRAM_BOT_NAME}" class="button">Commencer la conversation</a>
            <p>Avec votre compte, vous pouvez:</p>
            <ul>
              <li>💬 Discuter avec l'IA sur Telegram</li>
              <li>🔍 Effectuer des recherches sur le web</li>
              <li>📚 Bénéficier d'une mémoire contextuelle</li>
            </ul>
          </div>
          <div class="footer">
            <p>Questions? Répondez à cet email ou contactez le support.</p>
            <p>© 2026 Telegram AI Bot</p>
          </div>
        </div>
      </body>
      </html>
    `
  }),

  subscriptionConfirmation: (plan: string, amount: number) => ({
    subject: '✅ Abonnement confirmé',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #28a745; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 20px; }
          .plan { background: white; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #28a745; }
          .amount { font-size: 24px; color: #28a745; font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✅ Abonnement Confirmé!</h1>
          </div>
          <div class="content">
            <p>Votre abonnement a été activé avec succès.</p>
            <div class="plan">
              <strong>Plan:</strong> ${plan}<br>
              <span class="amount">${amount.toFixed(2)}€/mois</span>
            </div>
            <p>Vous pouvez maintenant:</p>
            <ul>
              <li>Utiliser l'IA sans limites</li>
              <li>Accéder à la recherche web</li>
              <li>Gérer votre abonnement dans le portal client</li>
            </ul>
          </div>
        </div>
      </body>
      </html>
    `
  }),

  paymentReceipt: (amount: number, invoiceNumber: string) => ({
    subject: '🧾 Reçu de paiement',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .invoice { background: #f9f9f9; padding: 20px; border-radius: 10px; }
          .total { font-size: 20px; font-weight: bold; color: #28a745; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>🧾 Reçu de paiement</h1>
          <div class="invoice">
            <p><strong>Numéro de facture:</strong> ${invoiceNumber}</p>
            <p><strong>Date:</strong> ${new Date().toLocaleDateString('fr-FR')}</p>
            <hr>
            <p><strong>Montant:</strong> <span class="total">${amount.toFixed(2)}€</span></p>
            <p><strong>Statut:</strong> Payé ✅</p>
          </div>
          <p>Merci pour votre confiance!</p>
        </div>
      </body>
      </html>
    `
  }),

  subscriptionCanceled: (plan: string) => ({
    subject: '⚠️ Abonnement annulé',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .warning { background: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>⚠️ Abonnement annulé</h1>
          <p>Votre abonnement ${plan} a été annulé.</p>
          <div class="warning">
            <p><strong>Ce qui change:</strong></p>
            <ul>
              <li>Vous garderez l'accès jusqu'à la fin de votre période payée</li>
              <li>Vous ne serez pas facturé à nouveau</li>
            </ul>
          </div>
          <p>Pour réactiver votre abonnement, contactez le support.</p>
        </div>
      </body>
      </html>
    `
  }),

  dunningWarning: (daysRemaining: number) => ({
    subject: '⚠️ Paiement en attente',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .urgent { background: #f8d7da; padding: 15px; border-radius: 5px; border-left: 4px solid #dc3545; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>⚠️ Paiement en attente</h1>
          <div class="urgent">
            <p><strong>Attention:</strong> Votre paiement n'a pas pu être traité.</p>
            <p>Vous avez <strong>${daysRemaining} jours</strong> pour mettre à jour votre méthode de paiement.</p>
          </div>
          <p>Après ce délai, votre abonnement sera suspendu.</p>
          <a href="${process.env.PORTAL_URL || 'https://portal.telegram-ai.bot'}" 
             style="display:inline-block;background:#007bff;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;">
            Mettre à jour le paiement
          </a>
        </div>
      </body>
      </html>
    `
  })
};

// ═══════════════════════════════════════════════════════════════════════════════
// Email Service
// ═══════════════════════════════════════════════════════════════════════════════

class EmailService {
  private provider: EmailProvider;

  constructor() {
    this.provider = getEmailProvider();
  }

  async sendWelcomeEmail(to: string, name: string): Promise<boolean> {
    const template = templates.welcome(name);
    const result = await this.provider.send({
      to,
      subject: template.subject,
      html: template.html
    });
    return result.success;
  }

  async sendSubscriptionConfirmation(to: string, plan: string, amount: number): Promise<boolean> {
    const template = templates.subscriptionConfirmation(plan, amount);
    const result = await this.provider.send({
      to,
      subject: template.subject,
      html: template.html
    });
    return result.success;
  }

  async sendPaymentReceipt(to: string, amount: number, invoiceNumber: string): Promise<boolean> {
    const template = templates.paymentReceipt(amount, invoiceNumber);
    const result = await this.provider.send({
      to,
      subject: template.subject,
      html: template.html
    });
    return result.success;
  }

  async sendSubscriptionCanceled(to: string, plan: string): Promise<boolean> {
    const template = templates.subscriptionCanceled(plan);
    const result = await this.provider.send({
      to,
      subject: template.subject,
      html: template.html
    });
    return result.success;
  }

  async sendDunningWarning(to: string, daysRemaining: number): Promise<boolean> {
    const template = templates.dunningWarning(daysRemaining);
    const result = await this.provider.send({
      to,
      subject: template.subject,
      html: template.html
    });
    return result.success;
  }
}

// Export singleton instance
export const emailService = new EmailService();

// Export for testing
export { EmailService, templates };
