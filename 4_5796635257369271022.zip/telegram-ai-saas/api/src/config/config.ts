// ═══════════════════════════════════════════════════════════════════════════════
// CONFIG - Environment Configuration
// ═══════════════════════════════════════════════════════════════════════════════

import dotenv from 'dotenv';
dotenv.config();

export const config = {
  // Server
  host: process.env.HOST || '0.0.0.0',
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  isDev: process.env.NODE_ENV !== 'production',

  // Database
  databaseUrl: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/telegram_ai_saas',

  // Telegram Bot
  telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
  telegramWebhookUrl: process.env.TELEGRAM_WEBHOOK_URL || '',

  // JWT
  jwtSecret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',

  // Encryption (for API keys storage)
  encryptionKey: process.env.ENCRYPTION_KEY || '32-character-encryption-key-here!',

  // Licensing
  licenseSecret: process.env.LICENSE_SECRET || 'license-signing-secret',

  // Ollama (local AI)
  ollamaUrl: process.env.OLLAMA_URL || 'http://localhost:11434',
  ollamaModel: process.env.OLLAMA_MODEL || 'llama3',

  // OpenAI (optional - client brings own key)
  openaiApiKey: process.env.OPENAI_API_KEY || '',

  // Brave Search (optional - client brings own key)
  braveApiKey: process.env.BRAVE_API_KEY || '',

  // CORS
  corsOrigins: process.env.CORS_ORIGINS?.split(',') || ['*'],

  // Logging
  logLevel: process.env.LOG_LEVEL || 'info',

  // Lemon Squeezy (payments)
  lemonSqueezyApiKey: process.env.LEMON_SQUEEZY_API_KEY || '',
  lemonSqueezyWebhookSecret: process.env.LEMON_SQUEEZY_WEBHOOK_SECRET || '',
  lemonSqueezyStoreId: process.env.LEMON_SQUEEZY_STORE_ID || '',

  // Pricing
  pricing: {
    promo: {
      monthlyPrice: 4.99,
      yearlyPrice: 49.99,
      credits: 1000,
      features: ['AI Assistant', '1000 messages/month', 'Basic support']
    },
    standard: {
      monthlyPrice: 9.99,
      yearlyPrice: 99.99,
      credits: 5000,
      features: ['AI Assistant', '5000 messages/month', 'Priority support', 'Advanced features']
    }
  },

  // Rate Limits
  rateLimits: {
    messagesPerUser: parseInt(process.env.RATE_LIMIT_MESSAGES || '100', 10),
    apiKeysPerUser: parseInt(process.env.RATE_LIMIT_API_KEYS || '10', 10),
    webSearchesPerUser: parseInt(process.env.RATE_LIMIT_WEB_SEARCH || '50', 10)
  }
};
