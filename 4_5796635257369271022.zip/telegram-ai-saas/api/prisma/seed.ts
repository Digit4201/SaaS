// ═══════════════════════════════════════════════════════════════════════════
// SEED - Création des plans par défaut
// ═══════════════════════════════════════════════════════════════════════════
// Ce script initialise la base de données avec les plans d'abonnement
// ═══════════════════════════════════════════════════════════════════════════

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Début du seed...\n');

  // ═══════════════════════════════════════════════════════════════════════════
  // PLANS D'ABONNEMENT
  // ═══════════════════════════════════════════════════════════════════════════

  const plans = [
    {
      lemon_variant_id: 'promo_4_99',
      name: 'Promo',
      description: 'Offre promotionnelle à vie - Accès illimité à l\'IA',
      price_cents: 499, // 4.99€
      monthly_limit: 0, // Illimité
      features_json: {
        ai_model: 'gpt-3.5-turbo',
        priority: 'standard',
        support: 'basic',
        history_messages: 1000
      }
    },
    {
      lemon_variant_id: 'standard_9_99',
      name: 'Standard',
      description: 'Accès complet à l\'IA - Illimité',
      price_cents: 999, // 9.99€
      monthly_limit: 0, // Illimité
      features_json: {
        ai_model: 'gpt-3.5-turbo',
        priority: 'standard',
        support: 'priority',
        history_messages: 5000
      }
    }
  ];

  // ═══════════════════════════════════════════════════════════════════════════
  // MODÈLES OLLAMA (Optionnel - pour fallback local)
  // ═══════════════════════════════════════════════════════════════════════════

  const ollamaModels = [
    {
      name: 'llama3',
      display_name: 'Llama 3',
      description: 'Modèle Meta open-source, excellent rapport qualité/gratuité',
      is_available: false,
      is_default: false,
      temperature: 0.7,
      max_tokens: 4096,
      cost_per_1k_tokens: 0
    },
    {
      name: 'mistral',
      display_name: 'Mistral 7B',
      description: 'Modèle français, rapide et efficace',
      is_available: false,
      is_default: false,
      temperature: 0.7,
      max_tokens: 4096,
      cost_per_1k_tokens: 0
    }
  ];

  // ═══════════════════════════════════════════════════════════════════════════
  // FEATURE FLAGS PAR DÉFAUT
  // ═══════════════════════════════════════════════════════════════════════════

  const featureFlags = [
    {
      key: 'ai_generation',
      name: 'Génération IA',
      description: 'Permet la génération de réponses par IA',
      is_enabled: true,
      rollout_percent: 100
    },
    {
      key: 'streaming',
      name: 'Streaming réponses',
      description: 'Affiche les réponses en temps réel',
      is_enabled: true,
      rollout_percent: 100
    },
    {
      key: 'image_generation',
      name: 'Génération d\'images',
      description: 'Permet de générer des images (DALL-E)',
      is_enabled: false,
      rollout_percent: 0
    },
    {
      key: 'file_upload',
      name: 'Upload de fichiers',
      description: 'Permet d\'uploader des fichiers pour analyse',
      is_enabled: false,
      rollout_percent: 0
    }
  ];

  // ═══════════════════════════════════════════════════════════════════════════
  // EXÉCUTION
  // ═══════════════════════════════════════════════════════════════════════════

  try {
    // Créer les plans
    console.log('📦 Création des plans...\n');
    
    for (const plan of plans) {
      const existing = await prisma.plan.findUnique({
        where: { lemon_variant_id: plan.lemon_variant_id }
      });

      if (existing) {
        console.log(`  ⏭️  Plan "${plan.name}" déjà existant`);
        
        // Mettre à jour
        await prisma.plan.update({
          where: { id: existing.id },
          data: {
            name: plan.name,
            description: plan.description,
            price_cents: plan.price_cents,
            monthly_limit: plan.monthly_limit,
            features_json: plan.features_json,
            is_active: true
          }
        });
        console.log(`  🔄 Plan "${plan.name}" mis à jour\n`);
      } else {
        await prisma.plan.create({ data: plan });
        console.log(`  ✅ Plan "${plan.name}" créé (${plan.price_cents / 100}€)\n`);
      }
    }

    // Créer les modèles Ollama
    console.log('🤖 Configuration des modèles IA...\n');
    
    for (const model of ollamaModels) {
      const existing = await prisma.oLLAMAModel.findUnique({
        where: { name: model.name }
      });

      if (existing) {
        console.log(`  ⏭️  Modèle "${model.display_name}" déjà configuré`);
      } else {
        await prisma.oLLAMAModel.create({ data: model });
        console.log(`  ✅ Modèle "${model.display_name}" ajouté\n`);
      }
    }

    // Créer les feature flags
    console.log('🚩 Configuration des feature flags...\n');
    
    for (const flag of featureFlags) {
      const existing = await prisma.featureFlag.findUnique({
        where: { key: flag.key }
      });

      if (existing) {
        console.log(`  ⏭️  Flag "${flag.name}" déjà configuré`);
      } else {
        await prisma.featureFlag.create({ data: flag });
        console.log(`  ✅ Flag "${flag.name}" créé\n`);
      }
    }

    console.log('✨ Seed terminé avec succès!\n');

    // Afficher les plans créés
    console.log('📋 Récapitulatif des plans:\n');
    
    const allPlans = await prisma.plan.findMany({
      where: { is_active: true },
      orderBy: { price_cents: 'asc' }
    });

    for (const plan of allPlans) {
      const price = plan.price_cents / 100;
      const limit = plan.monthly_limit === 0 ? 'Illimité' : `${plan.monthly_limit}/mois`;
      console.log(`  • ${plan.name}: ${price}€ - ${limit}`);
    }

    console.log('\n🚀 Prêt à accueillir les utilisateurs!\n');

  } catch (error) {
    console.error('❌ Erreur lors du seed:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

// Exécuter le seed
main()
  .then(() => {
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
