#!/bin/bash
# ═══════════════════════════════════════════════════════════
# BACKUP SCRIPT - PostgreSQL + Redis
# ═══════════════════════════════════════════════════════════
# Cron: 0 * * * * /app/scripts/backup.sh
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# Configuration
BACKUP_DIR="${BACKUP_DIR:-/backups}"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS="${RETENTION_DAYS:-7}"
POSTGRES_CONTAINER="telegram-ai-postgres"
REDIS_CONTAINER="telegram-ai-redis"
API_CONTAINER="telegram-ai-api"
S3_BUCKET="${S3_BUCKET:-}"
S3_ENDPOINT="${S3_ENDPOINT:-}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Backup PostgreSQL
backup_postgres() {
    log_info "Starting PostgreSQL backup..."
    
    BACKUP_FILE="$BACKUP_DIR/postgres_$DATE.dump"
    
    docker exec "$POSTGRES_CONTAINER" pg_dump \
        -U postgres \
        --no-owner \
        --no-privileges \
        --clean \
        --if-exists \
        telegram_ai > "$BACKUP_FILE"
    
    # Compress
    gzip "$BACKUP_FILE"
    BACKUP_FILE="${BACKUP_FILE}.gz"
    
    # Calculate checksum
    sha256sum "${BACKUP_FILE}" > "${BACKUP_FILE}.sha256"
    
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    log_success "PostgreSQL backup complete: $BACKUP_FILE ($SIZE)"
    
    # Upload to S3 if configured
    if [ -n "$S3_BUCKET" ]; then
        upload_s3 "$BACKUP_FILE" "postgres/"
        upload_s3 "${BACKUP_FILE}.sha256" "postgres/"
    fi
}

# Backup Redis
backup_redis() {
    log_info "Starting Redis backup..."
    
    BACKUP_FILE="$BACKUP_DIR/redis_$DATE.rdb"
    
    docker exec "$REDIS_CONTAINER" redis-cli BGSAVE
    sleep 5
    
    # Wait for BGSAVE to complete
    while [ "$(docker exec "$REDIS_CONTAINER" redis-cli LASTSAVE)" == "$(docker exec "$REDIS_CONTAINER" redis-cli LASTSAVE)" ]; do
        sleep 1
    done
    
    docker cp "$REDIS_CONTAINER:/data/dump.rdb" "$BACKUP_FILE"
    
    # Compress
    gzip "$BACKUP_FILE"
    BACKUP_FILE="${BACKUP_FILE}.gz"
    
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    log_success "Redis backup complete: $BACKUP_FILE ($SIZE)"
    
    # Upload to S3 if configured
    if [ -n "$S3_BUCKET" ]; then
        upload_s3 "$BACKUP_FILE" "redis/"
    fi
}

# Upload to S3/MinIO
upload_s3() {
    local FILE="$1"
    local PREFIX="$2"
    
    log_info "Uploading $FILE to S3..."
    
    if [ -n "$S3_ENDPOINT" ]; then
        # MinIO/S3 compatible
        aws --endpoint-url="$S3_ENDPOINT" s3 cp "$FILE" "s3://$S3_BUCKET/$PREFIX" --storage-class STANDARD
    else
        # Standard S3
        aws s3 cp "$FILE" "s3://$S3_BUCKET/$PREFIX"
    fi
    
    log_success "Upload complete"
}

# Cleanup old backups
cleanup() {
    log_info "Cleaning up backups older than $RETENTION_DAYS days..."
    
    # Local cleanup
    find "$BACKUP_DIR" -name "*.gz" -type f -mtime +$RETENTION_DAYS -delete
    find "$BACKUP_DIR" -name "*.sha256" -type f -mtime +$RETENTION_DAYS -delete
    
    # S3 cleanup
    if [ -n "$S3_BUCKET" ]; then
        if [ -n "$S3_ENDPOINT" ]; then
            aws --endpoint-url="$S3_ENDPOINT" s3 ls "s3://$S3_BUCKET/postgres/" | \
                awk '{print $4}' | \
                while read -r key; do
                    # Delete files older than retention
                    # Note: Simplified, should use proper date comparison
                done
        fi
    fi
    
    log_success "Cleanup complete"
}

# Main
main() {
    echo "╔══════════════════════════════════════════════════╗"
    echo "║     Telegram AI Bot SaaS - Backup Script         ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    
    backup_postgres
    backup_redis
    cleanup
    
    echo ""
    log_success "All backups complete!"
}

main
