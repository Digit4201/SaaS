#!/bin/bash
# ═══════════════════════════════════════════════════════════
# TEST RESTORE SCRIPT - Vérifie que les backups fonctionnent
# ═══════════════════════════════════════════════════════════
# Cron: 0 3 1 * * /app/scripts/test-restore.sh
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# Configuration
BACKUP_DIR="${BACKUP_DIR:-/backups}"
TEST_DIR="/tmp/restore_test_$$"
POSTGRES_CONTAINER="telegram-ai-postgres"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

# Find latest backup
find_latest_backup() {
    LATEST=$(ls -t "$BACKUP_DIR"/postgres_*.gz 2>/dev/null | head -1)
    if [ -z "$LATEST" ]; then
        log_error "No backup found in $BACKUP_DIR"
        exit 1
    fi
    log_info "Using backup: $LATEST"
    echo "$LATEST"
}

# Test PostgreSQL restore
test_postgres_restore() {
    local backup="$1"
    
    log_info "Testing PostgreSQL restore..."
    mkdir -p "$TEST_DIR"
    
    # Uncompress
    log_info "Decompressing backup..."
    gunzip -c "$backup" > "$TEST_DIR/test_restore.sql"
    
    # Create test database
    TEST_DB="test_restore_$$"
    docker exec -u postgres "$POSTGRES_CONTAINER" psql -c "DROP DATABASE IF EXISTS $TEST_DB;" 2>/dev/null || true
    docker exec -u postgres "$POSTGRES_CONTAINER" psql -c "CREATE DATABASE $TEST_DB;"
    
    # Restore to test database
    log_info "Restoring to test database..."
    if docker exec -i -u postgres "$POSTGRES_CONTAINER" psql "$TEST_DB" < "$TEST_DIR/test_restore.sql" > "$TEST_DIR/restore.log" 2>&1; then
        log_success "Restore completed successfully"
    else
        log_error "Restore failed!"
        cat "$TEST_DIR/restore.log"
        cleanup
        exit 1
    fi
    
    # Verify data integrity
    log_info "Verifying data integrity..."
    
    # Check tables exist
    TABLES=$(docker exec -u postgres "$POSTGRES_CONTAINER" psql -t -d "$TEST_DB" -c "\dt" 2>/dev/null | wc -l)
    if [ "$TABLES" -lt 5 ]; then
        log_error "Missing tables: found $TABLES, expected > 5"
        cleanup
        exit 1
    fi
    log_success "All tables present"
    
    # Check user count
    USER_COUNT=$(docker exec -u postgres "$POSTGRES_CONTAINER" psql -t -d "$TEST_DB" -c "SELECT COUNT(*) FROM users;" | xargs)
    log_info "Users in backup: $USER_COUNT"
    
    # Check message count
    MSG_COUNT=$(docker exec -u postgres "$POSTGRES_CONTAINER" psql -t -d "$TEST_DB" -c "SELECT COUNT(*) FROM messages;" | xargs)
    log_info "Messages in backup: $MSG_COUNT"
    
    # Check subscriptions
    SUB_COUNT=$(docker exec -u postgres "$POSTGRES_CONTAINER" psql -t -d "$TEST_DB" -c "SELECT COUNT(*) FROM subscriptions;" | xargs)
    log_info "Subscriptions in backup: $SUB_COUNT"
    
    # Cleanup test database
    docker exec -u postgres "$POSTGRES_CONTAINER" psql -c "DROP DATABASE $TEST_DB;" 2>/dev/null || true
    
    log_success "PostgreSQL restore test PASSED"
}

# Test Redis restore
test_redis_restore() {
    log_info "Testing Redis restore..."
    
    # Find latest Redis backup
    REDIS_BACKUP=$(ls -t "$BACKUP_DIR"/redis_*.gz 2>/dev/null | head -1)
    
    if [ -z "$REDIS_BACKUP" ]; then
        log_warn "No Redis backup found, skipping"
        return
    fi
    
    log_info "Using Redis backup: $REDIS_BACKUP"
    
    # Just verify the file is valid gzip
    if gunzip -t "$REDIS_BACKUP" 2>&1; then
        log_success "Redis backup file is valid"
    else
        log_error "Redis backup file is corrupted"
        exit 1
    fi
}

# Cleanup
cleanup() {
    log_info "Cleaning up test files..."
    rm -rf "$TEST_DIR"
}

# Send notification
notify() {
    local status="$1"
    local message="$2"
    
    # Log only for now
    log_info "[$status] $message"
    
    # Could add Slack/email notification here
}

# Main
main() {
    echo "╔══════════════════════════════════════════════════╗"
    echo "║     Telegram AI Bot SaaS - Restore Test          ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    
    BACKUP=$(find_latest_backup)
    
    test_postgres_restore "$BACKUP"
    test_redis_restore
    
    cleanup
    
    echo ""
    log_success "╔════════════════════════════════════════════════╗"
    log_success "║     ALL RESTORE TESTS PASSED ✅                 ║"
    log_success "╚════════════════════════════════════════════════╝"
    log_info "Backup is valid and restorable"
    
    notify "success" "Restore test passed"
}

main
