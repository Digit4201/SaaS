#!/bin/bash
# ═══════════════════════════════════════════════════════════
# ROTATE SECRETS SCRIPT - Auto-rotation tous les 90 jours
# ═══════════════════════════════════════════════════════════
# Usage: ./scripts/rotate-secrets.sh --add <new_secret> | --remove <old_secret>
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# Configuration
ENV_FILE=".env"
SECRETS_FILE=".secrets.json"  # Stocke les secrets chiffrés
MASTER_KEY="${MASTER_KEY:-}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

# Generate new secret
generate_secret() {
    openssl rand -hex 32
}

# Encrypt secret (AES-256-GCM)
encrypt_secret() {
    local secret="$1"
    if [ -z "$MASTER_KEY" ]; then
        MASTER_KEY=$(cat "$ENV_FILE" | grep "MASTER_KEY" | cut -d'=' -f2)
    fi
    echo "$secret" | openssl enc -aes-256-gcm -salt -pbkdf2 -pass pass:"$MASTER_KEY" -A
}

# Decrypt secret
decrypt_secret() {
    local encrypted="$1"
    if [ -z "$MASTER_KEY" ]; then
        MASTER_KEY=$(cat "$ENV_FILE" | grep "MASTER_KEY" | cut -d'=' -f2)
    fi
    echo "$encrypted" | openssl enc -aes-256-gcm -d -pbkdf2 -pass pass:"$MASTER_KEY" -A
}

# Add new secret (double-run période)
add_secret() {
    local new_secret="$1"
    local encrypted=$(encrypt_secret "$new_secret")
    
    log_info "Adding new secret to allowlist..."
    
    # Backup env file
    cp "$ENV_FILE" "${ENV_FILE}.backup.$(date +%Y%m%d_%H%M%S)"
    
    # Add to env file as temporary (accepted during double-run)
    # Note: In production, you'd update a secrets manager
    
    # Update LemonSqueezy webhook secret
    if [ -n "${LEMON_WEBHOOK_ID:-}" ]; then
        log_info "Updating LemonSqueezy webhook secret..."
        curl -X PUT "https://api.lemonsqueezy.com/v1/webhooks/${LEMON_WEBHOOK_ID}" \
            -H "Authorization: Bearer ${LEMON_API_KEY}" \
            -H "Content-Type: application/vnd.api+json" \
            -d "{
                \"data\": {
                    \"type\": \"webhooks\",
                    \"attributes\": {
                        \"secret\": \"$new_secret\"
                    }
                }
            }" || log_warn "Failed to update LemonSqueezy webhook"
    fi
    
    # Store in secrets file
    echo "$new_secret" >> "$SECRETS_FILE"
    
    log_success "New secret added. You have 24 hours to verify before removing old secret."
}

# Remove old secret
remove_secret() {
    local old_secret="$1"
    
    log_info "Removing old secret..."
    
    # Remove from secrets file
    if [ -f "$SECRETS_FILE" ]; then
        grep -v "^${old_secret}$" "$SECRETS_FILE" > "${SECRETS_FILE}.tmp" 2>/dev/null || true
        mv "${SECRETS_FILE}.tmp" "$SECRETS_FILE"
    fi
    
    log_success "Old secret removed"
}

# Show current secrets status
status() {
    log_info "Secrets Rotation Status"
    echo ""
    
    # Check if secrets file exists
    if [ -f "$SECRETS_FILE" ]; then
        SECRETS_COUNT=$(wc -l < "$SECRETS_FILE")
        log_info "Stored secrets: $SECRETS_COUNT"
    else
        log_info "No stored secrets file found"
    fi
    
    # Show last rotation date from file
    if [ -f "$ENV_FILE" ]; then
        if grep -q "SECRET_ROTATION_DATE" "$ENV_FILE"; then
            ROTATION_DATE=$(grep "SECRET_ROTATION_DATE" "$ENV_FILE" | cut -d'=' -f2)
            log_info "Last rotation: $ROTATION_DATE"
        else
            log_warn "No rotation date found"
        fi
    fi
}

# Full rotation workflow
rotate() {
    log_info "Starting full secret rotation..."
    
    # Generate new secret
    NEW_SECRET=$(generate_secret)
    log_info "New secret generated"
    
    # Add new secret (start double-run)
    add_secret "$NEW_SECRET"
    
    # Update env file with rotation date
    if ! grep -q "SECRET_ROTATION_DATE" "$ENV_FILE"; then
        echo "SECRET_ROTATION_DATE=$(date +%Y-%m-%d)" >> "$ENV_FILE"
    else
        sed -i "s/SECRET_ROTATION_DATE=.*/SECRET_ROTATION_DATE=$(date +%Y-%m-%d)/" "$ENV_FILE"
    fi
    
    log_success "Secret rotation initiated"
    log_warn "IMPORTANT: Wait 24 hours before running --remove to confirm everything works"
    log_info "After 24 hours, run: $0 --remove $(cat "$ENV_FILE" | grep "TELEGRAM_BOT_TOKEN" | cut -d':' -f2 | cut -d'@' -f1)"
}

# Main
main() {
    echo "╔══════════════════════════════════════════════════╗"
    echo "║     Telegram AI Bot SaaS - Secrets Rotation      ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    
    if [ $# -lt 1 ]; then
        status
        echo ""
        log_info "Usage:"
        echo "  $0 --add <secret>      Add new secret (start double-run)"
        echo "  $0 --remove <secret>   Remove old secret (after 24h)"
        echo "  $0 --rotate            Full rotation workflow"
        echo "  $0 --status            Show rotation status"
        echo ""
        log_info "Recommended: Run --rotate every 90 days"
        exit 0
    fi
    
    case "$1" in
        --add)
            if [ -z "${2:-}" ]; then
                log_error "Missing secret argument"
                exit 1
            fi
            add_secret "$2"
            ;;
        --remove)
            if [ -z "${2:-}" ]; then
                log_error "Missing secret argument"
                exit 1
            fi
            remove_secret "$2"
            ;;
        --rotate)
            rotate
            ;;
        --status)
            status
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
}

main "$@"
