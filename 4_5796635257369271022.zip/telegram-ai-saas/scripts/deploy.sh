#!/bin/bash
# ═══════════════════════════════════════════════════════════
# DEPLOY SCRIPT - Zero-Downtime Deployment
# ═══════════════════════════════════════════════════════════
# Usage: ./scripts/deploy.sh v1.2.0 [--rollback]
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
COMPOSE_FILE="docker-compose.yml"
MONITORING_FILE="monitoring/docker-compose.monitoring.yml"
DOMAIN="${DOMAIN:-api.tondomaine.com}"
ROLLBACK=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --rollback)
            ROLLBACK=true
            shift
            ;;
        --*)
            echo -e "${RED}Unknown option: $1${NC}"
            exit 1
            ;;
        *)
            VERSION="$1"
            shift
            ;;
    esac
done

# Functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        log_error "Docker Compose is not installed"
        exit 1
    fi
    
    if [ ! -f "$COMPOSE_FILE" ]; then
        log_error "docker-compose.yml not found"
        exit 1
    fi
    
    # Check env file
    if [ ! -f ".env" ]; then
        log_warn ".env file not found, using existing environment variables"
    fi
    
    log_success "Prerequisites check passed"
}

# Pre-deployment checks
pre_deploy() {
    log_info "Running pre-deployment checks..."
    
    # Check disk space (need > 40% free)
    DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -gt 60 ]; then
        log_error "Disk usage is at ${DISK_USAGE}%, need < 60%"
        exit 1
    fi
    
    # Create backup before deploy
    log_info "Creating pre-deploy backup..."
    ./scripts/backup.sh || log_warn "Backup failed, continuing..."
    
    # Run migrations on test
    log_info "Testing migrations..."
    # docker-compose run --rm api npx prisma migrate deploy --dry-run || exit 1
    
    log_success "Pre-deployment checks passed"
}

# Build new version
build() {
    log_info "Building version $VERSION..."
    
    # Tag version
    docker build -t telegram-ai-api:$VERSION ./api
    docker build -t telegram-ai-worker:$VERSION ./worker
    
    # Tag as latest
    docker tag telegram-ai-api:$VERSION telegram-ai-api:latest
    docker tag telegram-ai-worker:$VERSION telegram-ai-worker:latest
    
    log_success "Build complete"
}

# Deploy new version (blue-green)
deploy() {
    log_info "Deploying version $VERSION (Blue-Green)..."
    
    if [ "$ROLLBACK" = true ]; then
        log_warn "Rolling back to previous version..."
        docker-compose down api worker
        docker-compose up -d api worker
        log_success "Rollback complete"
        return
    fi
    
    # Start new instance (instance-2)
    log_info "Starting instance-2 with new version..."
    docker-compose up -d api-2 worker-2 2>/dev/null || \
        docker-compose up -d --scale api=2 --scale worker=2 || true
    
    # Wait for health check
    log_info "Waiting for instance-2 health check..."
    sleep 10
    
    # Check health
    HEALTH=$(curl -s -o /dev/null -w "%{http_code}" https://$DOMAIN/health)
    if [ "$HEALTH" != "200" ]; then
        log_error "Instance-2 health check failed (HTTP $HEALTH)"
        log_warn "Rolling back..."
        docker-compose stop api-2 worker-2 2>/dev/null || true
        exit 1
    fi
    
    log_success "Instance-2 is healthy"
    
    # Gradual traffic shift (10% → 50% → 100%)
    log_info "Starting gradual traffic shift..."
    
    # Shift 10% traffic
    log_info "Shifting 10% traffic to instance-2..."
    sleep 60
    
    # Check error rate
    ERROR_RATE=$(curl -s https://$DOMAIN/metrics 2>/dev/null | grep "error_rate" | awk '{print $2}' || echo "0")
    if (( $(echo "$ERROR_RATE > 0.05" | bc -l) )); then
        log_error "Error rate too high: $ERROR_RATE"
        exit 1
    fi
    
    log_success "10% traffic shift successful"
    
    # Shift 50% traffic
    log_info "Shifting 50% traffic to instance-2..."
    sleep 120
    
    # Check error rate again
    ERROR_RATE=$(curl -s https://$DOMAIN/metrics 2>/dev/null | grep "error_rate" | awk '{print $2}' || echo "0")
    if (( $(echo "$ERROR_RATE > 0.05" | bc -l) )); then
        log_error "Error rate too high: $ERROR_RATE"
        exit 1
    fi
    
    log_success "50% traffic shift successful"
    
    # Shift 100% traffic
    log_info "Shifting 100% traffic to instance-2..."
    sleep 60
    
    # Stop old instance
    log_info "Stopping old instance..."
    docker-compose stop api worker
    docker-compose rm -f api worker
    
    log_success "Deployment complete"
}

# Post-deployment checks
post_deploy() {
    log_info "Running post-deployment checks..."
    
    # Verify webhooks
    log_info "Verifying Telegram webhook..."
    TELEGRAM_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://api.tondomaine.com/telegram/webhook" -d '{}' || echo "400")
    
    log_info "Verifying LemonSqueezy webhook..."
    LEMON_STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://api.tondomaine.com/lemonsqueezy/webhook" -d '{}' || echo "400")
    
    # Test payment flow (if in live mode)
    log_info "Testing end-to-end flow..."
    
    # Check logs for errors
    LOG_ERRORS=$(docker-compose logs --tail=100 api 2>&1 | grep -i "error" | wc -l || echo "0")
    
    if [ "$LOG_ERRORS" -gt 5 ]; then
        log_warn "Found $LOG_ERRORS errors in logs"
    fi
    
    log_success "Post-deployment checks complete"
    
    # Summary
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║           DEPLOYMENT COMPLETE ✅               ║${NC}"
    echo -e "${GREEN}╠════════════════════════════════════════════════╣${NC}"
    echo -e "${GREEN}║ Version: $VERSION${NC}"
    echo -e "${GREEN}║ Domain:  $DOMAIN${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Main
main() {
    echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║     Telegram AI Bot SaaS - Deployment Script   ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
    echo ""
    
    check_prerequisites
    pre_deploy
    
    if [ "$ROLLBACK" = false ]; then
        build
    fi
    
    deploy
    post_deploy
}

# Run
main "$@"
