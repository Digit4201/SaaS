// ═══════════════════════════════════════════════════════════════════
// VALIDATION UTILITIES
// Input validation and sanitization utilities
// ═══════════════════════════════════════════════════════════════════

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

/**
 * Validate Telegram ID format (numeric string)
 */
export function isValidTelegramId(telegramId: string): boolean {
  const telegramIdRegex = /^\d{5,15}$/;
  return telegramIdRegex.test(telegramId);
}

/**
 * Sanitize string by removing HTML tags and dangerous characters
 */
export function sanitizeString(input: string): string {
  return input
    .replace(/<[^>]*>/g, '') // Remove HTML tags
    .replace(/[<>]/g, '') // Remove remaining angle brackets
    .trim();
}

/**
 * Validate API key format
 */
export function isValidApiKey(key: string): boolean {
  if (!key || key.length < 10) return false;
  
  // Common API key patterns
  const patterns = [
    /^sk-[a-zA-Z0-9]{20,}$/, // OpenAI
    /^sk_live_[a-zA-Z0-9]{20,}$/, // Stripe/LemonSqueezy
    /^xoxb-[0-9]{10,}$/ // Slack
  ];
  
  return patterns.some(pattern => pattern.test(key));
}

/**
 * Validate UUID format
 */
export function isValidUUID(value: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(value);
}

/**
 * Validate URL format
 */
export function isValidUrl(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

/**
 * Validate and sanitize command arguments
 */
export function sanitizeCommandArg(arg: string): string {
  return arg
    .replace(/[;&|`$(){}[\]\\]/g, '') // Remove shell special characters
    .trim();
}
