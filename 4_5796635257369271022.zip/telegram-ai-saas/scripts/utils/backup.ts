// ═══════════════════════════════════════════════════════════════════
// BACKUP UTILITIES
// Backup filename generation and retention utilities
// ═══════════════════════════════════════════════════════════════════

import path from 'path';

/**
 * Generate backup filename with timestamp
 */
export function generateBackupFilename(
  type: 'postgres' | 'redis' | 'full',
  extension: string = 'dump'
): string {
  const timestamp = new Date()
    .toISOString()
    .replace(/[-:T]/g, '')
    .replace(/\..+/, '');
  
  return `${type}_${timestamp}.${extension}`;
}

/**
 * Calculate which files should be deleted based on retention
 */
export interface BackupFile {
  name: string;
  mtime: Date;
  path: string;
}

export function calculateRetention(
  files: BackupFile[],
  retentionDays: number
): string[] {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
  
  return files
    .filter(file => file.mtime < cutoffDate)
    .map(file => file.name);
}

/**
 * Get file size in human readable format
 */
export function formatFileSize(bytes: number): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(2)} ${units[unitIndex]}`;
}

/**
 * Calculate checksum of a file
 */
export async function calculateChecksum(
  filePath: string,
  algorithm: string = 'sha256'
): Promise<string> {
  const crypto = await import('crypto');
  const fs = await import('fs');
  
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash(algorithm);
    const stream = fs.createReadStream(filePath);
    
    stream.on('data', data => hash.update(data));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

/**
 * Verify checksum matches expected value
 */
export async function verifyChecksum(
  filePath: string,
  expectedChecksum: string
): Promise<boolean> {
  const actualChecksum = await calculateChecksum(filePath);
  return actualChecksum === expectedChecksum;
}
