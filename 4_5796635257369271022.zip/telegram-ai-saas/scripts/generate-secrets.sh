#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# GENERATE SECRETS - Generate secure secrets for .env
# ═══════════════════════════════════════════════════════════════════
# Usage: ./generate-secrets.sh
# ═══════════════════════════════════════════════════════════════════

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║     Telegram AI Bot SaaS - Secrets Generator            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Generate secrets
TELEGRAM_WEBHOOK_SECRET=$(openssl rand -hex 32)
LEMON_WEBHOOK_SECRET=$(openssl rand -hex 32)
POSTGRES_PASSWORD=$(openssl rand -hex 32)
ENCRYPTION_KEY=$(openssl rand -hex 32)
SESSION_SECRET=$(openssl rand -hex 64)
JWT_SECRET=$(openssl rand -hex 64)
MINIO_ROOT_PASSWORD=$(openssl rand -hex 32)
POSTGRES_REPLICATION_PASSWORD=$(openssl rand -hex 32)

log_info "Generated secrets:"
echo ""

# Create .env file
cat > .env << EOF
# ═══════════════════════════════════════════════════════════
# TELEGRAM AI BOT SAAS - Environment Variables
# ═══════════════════════════════════════════════════════════
# GENERATED: $(date -u '+%Y-%m-%d %H:%M:%S UTC')
# ═══════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════
# DOMAIN
# ═══════════════════════════════════════════════════════════
DOMAIN=api.tondomaine.com

# ═══════════════════════════════════════════════════════════
# TELEGRAM
# ═══════════════════════════════════════════════════════════
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
TELEGRAM_WEBHOOK_SECRET=${TELEGRAM_WEBHOOK_SECRET}

# ═══════════════════════════════════════════════════════════
# LEMONSQUEEZY (remplace Stripe)
# ═══════════════════════════════════════════════════════════
LEMON_API_KEY=ls_xxxxxxxxxxxxxxxxxxxxxxxx
LEMON_WEBHOOK_SECRET=${LEMON_WEBHOOK_SECRET}
LEMON_STORE_ID=store_xxxxxxxxxxxxxxxxxx

# ═══════════════════════════════════════════════════════════
# OPENAI (BYOAI - client provides their own key)
# ═══════════════════════════════════════════════════════════
OPENAI_API_KEY=

# ═══════════════════════════════════════════════════════════
# POSTGRES
# ═══════════════════════════════════════════════════════════
POSTGRES_USER=telegram_ai
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
POSTGRES_DB=telegram_ai
DATABASE_URL=postgresql://\${POSTGRES_USER}:\${POSTGRES_PASSWORD}@postgres:5432/\${POSTGRES_DB}

# ═══════════════════════════════════════════════════════════
# REDIS
# ═══════════════════════════════════════════════════════════
REDIS_URL=redis://redis:6379

# ═══════════════════════════════════════════════════════════
# SECRETS (IMPORTANT: Ne jamais partager!)
# ═══════════════════════════════════════════════════════════
ENCRYPTION_KEY=${ENCRYPTION_KEY}
SESSION_SECRET=${SESSION_SECRET}
JWT_SECRET=${JWT_SECRET}

# ═══════════════════════════════════════════════════════════
# MINIO / S3 (optionnel)
# ═══════════════════════════════════════════════════════════
S3_BUCKET=telegram-ai-backups
S3_ENDPOINT=https://minio.local:9000
MINIO_ROOT_USER=admin
MINIO_ROOT_PASSWORD=${MINIO_ROOT_PASSWORD}

# ═══════════════════════════════════════════════════════════
# POSTGRES REPLICATION (disaster recovery)
# ═══════════════════════════════════════════════════════════
POSTGRES_REPLICATION_USER=replicator
POSTGRES_REPLICATION_PASSWORD=${POSTGRES_REPLICATION_PASSWORD}

# ═══════════════════════════════════════════════════════════
# MONITORING (optionnel)
# ═══════════════════════════════════════════════════════════
SENTRY_DSN=
LOG_LEVEL=info

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
DATA_RETENTION_DAYS=90
SECRET_ROTATION_DAYS=90
EOF

log_success "Generated .env file with secrets"
echo ""

# Display generated values (masked)
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  Generated Values (for reference):                      ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "TELEGRAM_WEBHOOK_SECRET=${TELEGRAM_WEBHOOK_SECRET}"
echo "LEMON_WEBHOOK_SECRET=${LEMON_WEBHOOK_SECRET}"
echo "POSTGRES_PASSWORD=${POSTGRES_PASSWORD}"
echo "ENCRYPTION_KEY=${ENCRYPTION_KEY}"
echo "SESSION_SECRET=${SESSION_SECRET}"
echo "JWT_SECRET=${JWT_SECRET}"
echo "MINIO_ROOT_PASSWORD=${MINIO_ROOT_PASSWORD}"
echo "POSTGRES_REPLICATION_PASSWORD=${POSTGRES_REPLICATION_PASSWORD}"
echo ""

log_warn "IMPORTANT: Store these values securely!"
log_warn "The .env file has been created in the current directory."
log_warn "Add .env to your .gitignore file!"

echo ""
log_success "Done! Run 'docker-compose up -d' to start the application."
