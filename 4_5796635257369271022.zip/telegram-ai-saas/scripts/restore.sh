#!/bin/bash
# ═══════════════════════════════════════════════════════════
# RESTORE SCRIPT - PostgreSQL + Redis
# ═══════════════════════════════════════════════════════════
# Usage: ./scripts/restore.sh <backup_file.dump.gz>
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# Configuration
BACKUP_DIR="${BACKUP_DIR:-/backups}"
POSTGRES_CONTAINER="telegram-ai-postgres"
REDIS_CONTAINER="telegram-ai-redis"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

# Check arguments
if [ $# -lt 1 ]; then
    log_error "Usage: $0 <backup_file.dump.gz>"
    log_info "Available backups:"
    ls -la "$BACKUP_DIR"/*.gz 2>/dev/null || echo "  No backups found in $BACKUP_DIR"
    exit 1
fi

BACKUP_FILE="$1"

# Check if file exists
if [ ! -f "$BACKUP_FILE" ]; then
    # Try in backup directory
    if [ -f "$BACKUP_DIR/$BACKUP_FILE" ]; then
        BACKUP_FILE="$BACKUP_DIR/$BACKUP_FILE"
    else
        log_error "Backup file not found: $BACKUP_FILE"
        exit 1
    fi
fi

# Confirmation
log_warn "This will RESTORE the database from: $BACKUP_FILE"
log_warn "All current data will be OVERWRITTEN!"
echo ""
read -p "Are you sure you want to continue? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    log_info "Aborted"
    exit 0
fi

# Pre-restore checks
pre_restore() {
    log_info "Running pre-restore checks..."
    
    # Check if PostgreSQL is running
    if ! docker ps | grep -q "$POSTGRES_CONTAINER"; then
        log_error "PostgreSQL container is not running"
        exit 1
    fi
    
    # Create pre-restore backup
    log_info "Creating pre-restore backup..."
    ./scripts/backup.sh || log_warn "Pre-restore backup failed"
    
    log_success "Pre-restore checks passed"
}

# Stop services
stop_services() {
    log_info "Stopping API and Worker services..."
    docker-compose stop api worker
    log_success "Services stopped"
}

# Restore PostgreSQL
restore_postgres() {
    log_info "Restoring PostgreSQL..."
    
    # Uncompress if needed
    if [[ "$BACKUP_FILE" == *.gz ]]; then
        TEMP_FILE=$(mktemp)
        gunzip -c "$BACKUP_FILE" > "$TEMP_FILE"
    else
        TEMP_FILE="$BACKUP_FILE"
    fi
    
    # Drop and recreate database
    log_info "Dropping current database..."
    docker exec -u postgres "$POSTGRES_CONTAINER" psql -c "DROP DATABASE IF EXISTS telegram_ai;" 2>/dev/null || true
    docker exec -u postgres "$POSTGRES_CONTAINER" psql -c "CREATE DATABASE telegram_ai;"
    
    # Restore
    log_info "Importing backup..."
    docker exec -i -u postgres "$POSTGRES_CONTAINER" psql telegram_ai < "$TEMP_FILE"
    
    # Cleanup
    if [ -n "${TEMP_FILE:-}" ] && [ -f "$TEMP_FILE" ]; then
        rm "$TEMP_FILE"
    fi
    
    SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
    log_success "PostgreSQL restored from $BACKUP_FILE ($SIZE)"
}

# Restore Redis (optional)
restore_redis() {
    log_info "Restoring Redis (optional)..."
    
    # Find Redis backup
    REDIS_BACKUP=$(ls -t "$BACKUP_DIR"/redis_*.gz 2>/dev/null | head -1)
    
    if [ -z "$REDIS_BACKUP" ]; then
        log_warn "No Redis backup found, skipping"
        return
    fi
    
    log_info "Restoring Redis from $REDIS_BACKUP..."
    
    TEMP_FILE=$(mktemp)
    gunzip -c "$REDIS_BACKUP" > "$TEMP_FILE"
    
    docker cp "$TEMP_FILE" "$REDIS_CONTAINER:/data/dump.rdb"
    
    rm "$TEMP_FILE"
    
    log_success "Redis restored"
}

# Start services
start_services() {
    log_info "Starting services..."
    docker-compose start api worker
    
    # Wait for health
    sleep 10
    
    # Verify
    HEALTH=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/health || echo "000")
    if [ "$HEALTH" != "200" ]; then
        log_warn "API health check returned $HEALTH, please verify manually"
    else
        log_success "API is healthy"
    fi
}

# Verify restore
verify_restore() {
    log_info "Verifying restore..."
    
    # Check user count
    USER_COUNT=$(docker exec "$POSTGRES_CONTAINER" psql -t -U postgres -d telegram_ai -c "SELECT COUNT(*) FROM users;" 2>/dev/null | xargs || echo "0")
    log_info "Users in database: $USER_COUNT"
    
    # Check subscription count
    SUB_COUNT=$(docker exec "$POSTGRES_CONTAINER" psql -t -U postgres -d telegram_ai -c "SELECT COUNT(*) FROM subscriptions;" 2>/dev/null | xargs || echo "0")
    log_info "Subscriptions in database: $SUB_COUNT"
    
    # Check messages count
    MSG_COUNT=$(docker exec "$POSTGRES_CONTAINER" psql -t -U postgres -d telegram_ai -c "SELECT COUNT(*) FROM messages;" 2>/dev/null | xargs || echo "0")
    log_info "Messages in database: $MSG_COUNT"
    
    log_success "Restore verification complete"
}

# Main
main() {
    echo "╔══════════════════════════════════════════════════╗"
    echo "║     Telegram AI Bot SaaS - Restore Script        ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    
    pre_restore
    stop_services
    restore_postgres
    restore_redis
    start_services
    verify_restore
    
    echo ""
    log_success "Restore complete!"
    log_info "Please verify all webhooks and integrations manually"
}

main
