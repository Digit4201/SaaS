# Email Notifications Configuration

## SendGrid Setup

```env
# SendGrid API Key
SENDGRID_API_KEY=SG.xxx

# From address
EMAIL_FROM=noreply@tondomaine.com
EMAIL_FROM_NAME="Telegram AI"

# Templates
EMAIL_WELCOME_TEMPLATE_ID=d-xxx
EMAIL_PAYMENT_CONFIRM_TEMPLATE_ID=d-xxx
EMAIL_PAYMENT_FAILED_TEMPLATE_ID=d-xxx
EMAIL_SUBSCRIPTION_CANCELLED_TEMPLATE_ID=d-xxx
```

## Email Templates

### Welcome Email

```html
<!-- File: emails/welcome.html -->
<!DOCTYPE html>
<html>
<head>
  <title>Welcome to Telegram AI</title>
</head>
<body>
  <h1>Welcome {{name}}! 🎉</h1>
  <p>Thanks for joining Telegram AI!</p>
  <p>Your subscription: <strong>{{plan}}</strong></p>
  <p>You can now:</p>
  <ul>
    <li>Chat with AI on Telegram</li>
    <li>Access premium features</li>
    <li>Manage your subscription</li>
  </ul>
  <a href="{{portal_url}}">Open Dashboard</a>
</body>
</html>
```

### Payment Confirmation

```html
<!-- File: emails/payment-confirmed.html -->
<!DOCTYPE html>
<html>
<head>
  <title>Payment Confirmed</title>
</head>
<body>
  <h1>Payment Received! ✅</h1>
  <p>Thanks for your payment, {{name}}!</p>
  <p><strong>Amount:</strong> {{amount}}</p>
  <p><strong>Date:</strong> {{date}}</p>
  <p><strong>Invoice:</strong> <a href="{{invoice_url}}">Download PDF</a></p>
</body>
</html>
```

## Usage

```typescript
// src/services/email.ts
import { sendEmail } from './email';

await sendEmail({
  to: user.email,
  template: 'welcome',
  data: {
    name: user.name,
    plan: subscription.plan.display_name,
    portal_url: 'https://portal.tondomaine.com'
  }
});
```

## Setup

```bash
# Install SendGrid
npm install @sendgrid/mail

# Set environment variables
export SENDGRID_API_KEY=SG.xxx
```
