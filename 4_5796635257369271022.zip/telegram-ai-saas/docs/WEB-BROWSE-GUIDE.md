# 🌐 Guide d'Intégration - Navigation Web pour Agents IA

**Version:** 1.0  
**Date:** 2026-02-12

---

## 🎯 Vue d'Ensemble

Ce module permet à votre agent IA d'accéder à internet pour:
- 📝 **Rechercher** des informations en temps réel
- 📄 **Récupérer** le contenu de pages web
- 🔍 **Naviguer** et analyser des sites

---

## 🚀 Démarrage Rapide

### 1. Activer votre clé

```bash
# Vérifier que votre clé est valide
curl "https://api.votre-domaine.com/license/usage/VOTRE_CLE"

# Réponse:
{
  "valid": true,
  "browse_usage": {
    "searches_today": 0,
    "daily_limit": 100,
    "remaining": 100
  }
}
```

### 2. Faire une recherche

```bash
curl -X POST "https://api.votre-domaine.com/license/web/search" \
  -H "Content-Type: application/json" \
  -d '{
    "key": "VOTRE_CLE_UUID",
    "query": "actualités IA 2026",
    "num_results": 5
  }'
```

---

## 📡 Endpoints API

### 1. Vérifier l'Usage

**GET** `/license/usage/:key`

```bash
curl "https://api.votre-domaine.com/license/usage/550e8400-e29b-41d4-a716-446655440000"
```

**Réponse:**
```json
{
  "valid": true,
  "license": {
    "key": "550e84...",
    "expires_at": "2026-03-12T00:00:00.000Z",
    "remaining_uses": 29
  },
  "browse_usage": {
    "searches_today": 5,
    "daily_limit": 100,
    "remaining": 95
  }
}
```

---

### 2. Rechercher sur le Web

**POST** `/license/web/search`

```bash
curl -X POST "https://api.votre-domaine.com/license/web/search" \
  -H "Content-Type: application/json" \
  -d '{
    "key": "550e8400-e29b-41d4-a716-446655440000",
    "query": "dernières nouvelles sur l'IA",
    "num_results": 10
  }'
```

**Paramètres:**
| Paramètre | Type | Requis | Description |
|-----------|------|--------|-------------|
| `key` | string | ✅ | Votre clé de licence UUID |
| `query` | string | ✅ | Terme de recherche |
| `num_results` | number | ❌ | Nombre de résultats (défaut: 10) |

**Réponse:**
```json
{
  "success": true,
  "query": "dernières nouvelles sur l'IA",
  "results": [
    {
      "title": "L'IA atteint de nouveaux sommets en 2026",
      "url": "https://example.com/article1",
      "description": "Les dernières avancées en intelligence artificielle...",
      "age": "2h"
    },
    {
      "title": "GPT-5 et l'avenir de l'IA conversationnelle",
      "url": "https://example.com/article2",
      "description": "Analyse des nouveaux modèles de langage...",
      "age": "5h"
    }
  ],
  "credits_used": 1,
  "remaining": 94
}
```

---

### 3. Récupérer le Contenu d'une Page

**POST** `/license/web/fetch`

```bash
curl -X POST "https://api.votre-domaine.com/license/web/fetch" \
  -H "Content-Type: application/json" \
  -d '{
    "key": "550e8400-e29b-41d4-a716-446655440000",
    "url": "https://fr.wikipedia.org/wiki/Intelligence_artificielle",
    "extract_mode": "markdown",
    "max_chars": 10000
  }'
```

**Paramètres:**
| Paramètre | Type | Requis | Description |
|-----------|------|--------|-------------|
| `key` | string | ✅ | Votre clé de licence UUID |
| `url` | string | ✅ | URL de la page à récupérer |
| `extract_mode` | string | ❌ | `markdown` ou `text` (défaut: markdown) |
| `max_chars` | number | ❌ | Max caractères (défaut: 50000) |

**Réponse:**
```json
{
  "success": true,
  "url": "https://fr.wikipedia.org/wiki/Intelligence_artificielle",
  "title": "Intelligence artificielle — Wikipédia",
  "content": "# Intelligence artificielle\n\nL'intelligence artificielle (IA) est...",
  "truncated": false,
  "content_type": "text/html",
  "markdown": "# Intelligence artificielle\n\nL'intelligence artificielle (IA) est..."
}
```

---

### 4. Naviguer sur une Page

**POST** `/license/web/browse`

```bash
curl -X POST "https://api.votre-domaine.com/license/web/browse" \
  -H "Content-Type: application/json" \
  -d '{
    "key": "550e8400-e29b-41d4-a716-446655440000",
    "action": "snapshot",
    "url": "https://example.com/page",
    "selectors": [".article-content", "h1"]
  }'
```

**Paramètres:**
| Paramètre | Type | Requis | Description |
|-----------|------|--------|-------------|
| `key` | string | ✅ | Votre clé de licence UUID |
| `action` | string | ✅ | `snapshot`, `screenshot`, ou `navigate` |
| `url` | string | ✅ | URL à naviguer |
| `selectors` | array | ❌ | Sélecteurs CSS à extraire |

---

## 🔧 Intégration dans votre Agent

### Exemple Python

```python
import requests

class WebNavigator:
    BASE_URL = "https://api.votre-domaine.com/license"
    
    def __init__(self, license_key: str):
        self.license_key = license_key
    
    def search(self, query: str, num_results: int = 10) -> list:
        """Rechercher sur le web"""
        response = requests.post(
            f"{self.BASE_URL}/web/search",
            json={
                "key": self.license_key,
                "query": query,
                "num_results": num_results
            }
        )
        data = response.json()
        if data["success"]:
            return data["results"]
        return []
    
    def fetch(self, url: str, max_chars: int = 50000) -> dict:
        """Récupérer le contenu d'une page"""
        response = requests.post(
            f"{self.BASE_URL}/web/fetch",
            json={
                "key": self.license_key,
                "url": url,
                "max_chars": max_chars
            }
        )
        return response.json()
    
    def check_usage(self) -> dict:
        """Vérifier l'usage restant"""
        response = requests.get(
            f"{self.BASE_URL}/usage/{self.license_key}"
        )
        return response.json()

# Utilisation
navigator = WebNavigator("550e8400-e29b-41d4-a716-446655440000")

# Rechercher
results = navigator.search("actualités IA 2026")

# Récupérer une page
page = navigator.fetch("https://example.com/article")

# Vérifier l'usage
usage = navigator.check_usage()
print(f"Recherches restantes: {usage['browse_usage']['remaining']}")
```

### Exemple JavaScript/Node.js

```javascript
class WebNavigator {
  constructor(licenseKey) {
    this.licenseKey = licenseKey;
    this.baseUrl = 'https://api.votre-domaine.com/license';
  }
  
  async search(query, numResults = 10) {
    const response = await fetch(`${this.baseUrl}/web/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key: this.licenseKey,
        query,
        num_results: numResults
      })
    });
    return response.json();
  }
  
  async fetch(url, maxChars = 50000) {
    const response = await fetch(`${this.baseUrl}/web/fetch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key: this.licenseKey,
        url,
        max_chars: maxChars
      })
    });
    return response.json();
  }
}

// Utilisation
const navigator = new WebNavigator('550e8400-e29b-41d4-a716-446655440000');

const results = await navigator.search('dernières actualités tech');
console.log(results);
```

---

## 📊 Limites et Tarifs

| Plan | Recherches/jour | Contenu/page | Prix |
|------|-----------------|--------------|------|
| Promo | 100 | 50,000 | 4.99€/mois |
| Standard | 100 | 50,000 | 9.99€/mois |
| API Key | 500 | 100,000 | 29.99€/mois |

---

## ⚠️ Gestion des Erreurs

```json
{
  "error": "DAILY_LIMIT_REACHED",
  "message": "Limite de 100 requêtes/jour atteinte",
  "reset_at": "2026-02-13T00:00:00.000Z"
}
```

| Code d'erreur | Description | Action |
|--------------|-------------|--------|
| `INVALID_LICENSE` | Clé non trouvée | Vérifier la clé |
| `LICENSE_EXPIRED` | Clé expirée | Renouveler la licence |
| `LICENSE_REVOKED` | Clé révoquée | Contacter le support |
| `DAILY_LIMIT_REACHED` | Limite quotidienne atteinte | Attendre demain |
| `INVALID_URL` | URL invalide | Vérifier l'URL |

---

## 🎯 Cas d'Usage

### 1. Agent de Veille

```python
# Recherche quotidienne
news = navigator.search("intelligence artificielle 2026")

# Récupérer les articles
for article in news[:3]:
    content = navigator.fetch(article['url'])
    print(content['title'])
```

### 2. Analyse Concurrentielle

```python
# Comparer deux sites
site1 = navigator.fetch("https://concurrents.com")
site2 = navigator.fetch("https://autre-concurrent.com")

# Extraire les prix
prices1 = extract_prices(site1['content'])
prices2 = extract_prices(site2['content'])
```

### 3. Recherche d'Information

```python
# Rechercher et résumer
query = "comment créer une startup IA"
results = navigator.search(query, num_results=5)

# Récupérer et analyser
for r in results:
    content = navigator.fetch(r['url'])
    summary = summarize(content['content'])
```

---

## 📈 Meilleures Pratiques

1. **Cachez les résultats** - Ne refaite pas la même recherche
2. **Limitez le contenu** - Utilisez `max_chars` pour réduire les coûts
3. **Gérez les erreurs** - Always handle API errors gracefully
4. **Surveillez l'usage** - Vérifiez régulièrement `license/usage`

---

## 🔗 Liens Utiles

- Documentation API: `/docs`
- Support: support@votre-domaine.com
- Tableau de bord: `https://dashboard.votre-domaine.com`

---

*Document généré automatiquement*
