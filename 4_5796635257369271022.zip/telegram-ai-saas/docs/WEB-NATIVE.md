# 🌐 Web Tools Natifs OpenClaw

**Date:** 2026-02-12

---

## 🎯 Outils Disponibles (Intégrés!)

| Outil | Description | Status |
|--------|-------------|--------|
| `web_search` | Rechercher sur le web | ✅ Natif |
| `web_fetch` | Récupérer le contenu d'une page | ✅ Natif |

---

## ⚙️ Configuration

### 1. Configurer Brave API (déjà fait!)

```bash
# Ta clé est déjà configurée
openclaw configure --section web --brave-api-key "BSAvrz2ww5AneiwAcqkTNkQ3OVuo3Sy"
```

### 2. Vérifier la config

```bash
cat ~/.openclaw/openclaw.json | grep -A10 "web"
```

---

## 🚀 Utilisation Simple

### Recherche Web

```javascript
// Dans ton agent
await web_search({
  query: "actualités IA 2026",
  count: 10
})
```

**Paramètres:**
- `query` (requis): Terme de recherche
- `count` (optionnel): Nombre de résultats (1-10, défaut: 5)
- `country` (optionnel): Code pays (`"FR"`, `"US"`, etc.)
- `freshness` (optionnel): `pd` (24h), `pw` (1 sem), `pm` (1 mois)

---

### Récupérer une Page

```javascript
// Récupérer le contenu
await web_fetch({
  url: "https://exemple.com/article",
  extractMode: "markdown",
  maxChars: 50000
})
```

**Paramètres:**
- `url` (requis): URL à récupérer
- `extractMode`: `"markdown"` ou `"text"`
- `maxChars`: Limite de caractères

---

## 📋 Exemple d'Agent avec Web

```javascript
// Ton agent peut maintenant faire:

const research = async (topic) => {
  // 1. Rechercher
  const results = await web_search({
    query: topic,
    count: 5,
    freshness: "pw"
  })
  
  // 2. Récupérer les tops articles
  const articles = []
  for (const r of results.slice(0, 3)) {
    const content = await web_fetch({
      url: r.url,
      extractMode: "markdown"
    })
    articles.push({
      title: r.title,
      url: r.url,
      content: content
    })
  }
  
  return articles
}

// Utilisation
const articles = await research("dernières actualités IA")
for (const a of articles) {
  console.log(`📄 ${a.title}`)
}
```

---

## 🔧 Configuration Avancée

```json5
{
  tools: {
    web: {
      search: {
        enabled: true,
        provider: "brave",
        maxResults: 10,
        timeoutSeconds: 30,
        cacheTtlMinutes: 15
      },
      fetch: {
        enabled: true,
        maxChars: 50000,
        timeoutSeconds: 30,
        readability: true
      }
    }
  }
}
```

---

## 🎯 Utilisation pour tes Clients

### Via le Système de Licences

Tes clients peuvent utiliser `web_search` et `web_fetch` dans leur agent:

```javascript
// Dans leur agent Telegram
await web_search({
  query: "comment faire..."
})

await web_fetch({
  url: "https://documentation..."
})
```

---

## ✅ Résumé

| | |
|---|---|
| **web_search** | ✅ Déjà disponible |
| **web_fetch** | ✅ Déjà disponible |
| **Brave API** | ✅ Configuré (ta clé) |
| **Licence requise** | Non - C'est natif OpenClaw! |

---

## 🚀 Prochaines Étapes

Tes clients peuvent **déjà** utiliser la navigation web dans leur agent! Il suffit d'appeler:

```javascript
await web_search({ query: "..." })
await web_fetch({ url: "..." })
```

**C'est tout!** Pas besoin de système séparé - OpenClaw gère tout!

---

*Le système est déjà prêt!* 🎉
