# Monitoring Configuration

Monitoring stack: Prometheus + Grafana + Sentry

## 📊 Prometheus

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  # API metrics
  - job_name: 'telegram-ai-api'
    static_configs:
      - targets: ['api:3000']
    metrics_path: /metrics

  # PostgreSQL
  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres:9187']

  # Redis
  - job_name: 'redis'
    static_configs:
      - targets: ['redis:9121']
```

## 📈 Grafana Dashboards

### Infrastructure Dashboard

```json
{
  "dashboard": {
    "title": "Telegram AI - Infrastructure",
    "panels": [
      {
        "title": "CPU Usage",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(container_cpu_usage_seconds_total{container=~\"api|worker\"}[5m])",
            "legendFormat": "{{container}}"
          }
        ]
      },
      {
        "title": "Memory Usage",
        "type": "graph",
        "targets": [
          {
            "expr": "container_memory_usage_bytes{container=~\"api|worker|postgres|redis\"}",
            "legendFormat": "{{container}}"
          }
        ]
      },
      {
        "title": "HTTP Requests Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{status}}"
          }
        ]
      },
      {
        "title": "HTTP Errors",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total{status=~\"5..\"}[5m])",
            "legendFormat": "{{status}}"
          }
        ]
      },
      {
        "title": "PostgreSQL Connections",
        "type": "graph",
        "targets": [
          {
            "expr": "pg_stat_activity_count",
            "legendFormat": "Active"
          }
        ]
      },
      {
        "title": "Redis Memory",
        "type": "graph",
        "targets": [
          {
            "expr": "redis_memory_used_bytes",
            "legendFormat": "Used"
          }
        ]
      }
    ]
  }
}
```

### Business Dashboard

```json
{
  "dashboard": {
    "title": "Telegram AI - Business Metrics",
    "panels": [
      {
        "title": "Active Subscriptions",
        "type": "stat",
        "targets": [
          {
            "expr": "sum(subscription_status{status='active'})"
          }
        ]
      },
      {
        "title": "Messages per Day",
        "type": "graph",
        "targets": [
          {
            "expr": "count(messages_total by day)",
            "legendFormat": "{{day}}"
          }
        ]
      },
      {
        "title": "AI Usage by Provider",
        "type": "piechart",
        "targets": [
          {
            "expr": "sum(ai_requests_total) by (provider)",
            "legendFormat": "{{provider}}"
          }
        ]
      },
      {
        "title": "Revenue (MRR)",
        "type": "stat",
        "targets": [
          {
            "expr": "sum(lemon_payment_succeeded_amount)"
          }
        ]
      }
    ]
  }
}
```

## 🚨 Sentry Configuration

### Environment Variables

```env
SENTRY_DSN=https://xxx@sentry.io/xxx
SENTRY_ORG=your-org
SENTRY_PROJECT=telegram-ai
SENTRY_AUTH_TOKEN=xxx
```

### API Integration

```typescript
// src/config/sentry.ts
import * as Sentry from '@sentry/node';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  tracesSampleRate: 0.2,
  profilesSampleRate: 0.1,
  environment: process.env.NODE_ENV,
  
  // Filtres
  beforeSend(event, hint) {
    // Ignorer certains errors
    if (hint.originalException?.message?.includes('Socket closed')) {
      return null;
    }
    return event;
  },
  
  // Tags automatiques
  initialScope: {
    tags: {
      service: 'telegram-ai-api'
    }
  }
});
```

### Error Tracking

```typescript
// Capturer errors
try {
  await processPayment(order);
} catch (error) {
  Sentry.captureException(error, {
    extra: {
      order_id: order.id,
      amount: order.amount
    }
  });
}

// Capturer messages
Sentry.captureMessage('Payment failed', {
  level: 'error',
  extra: {
    order_id: order.id
  }
});

// Context utilisateur
Sentry.setUser({
  id: user.id,
  email: user.email,
  telegram_id: user.telegram_id
});
```

## 📊 Alertes

### AlertManager Config

```yaml
# alerts.yml
groups:
  - name: telegram-ai
    rules:
      # API down
      - alert: API Down
        expr: up{job="telegram-ai-api"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "API is down"
          description: "Telegram AI API is not responding"

      # High error rate
      - alert: High Error Rate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High error rate detected"
          description: "Error rate > 5%"

      # Database connections
      - alert: Database Connections High
        expr: pg_stat_activity_count > 80
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "PostgreSQL connections high"

      # Payment failures
      - alert: Payment Failure Rate
        expr: rate(lemon_payment_failed[1h]) > 0.1
        for: 10m
        labels:
          severity: critical
        annotations:
          summary: "High payment failure rate"
```

## 🔧 Setup Monitoring Stack

```bash
# Monitoring directory
cd monitoring/

# Start monitoring
docker-compose -f docker-compose.monitoring.yml up -d

# Accès:
# - Prometheus: http://localhost:9090
# - Grafana: http://localhost:3001 (admin/admin)
```

## 📈 Métriques Personnalisées

```typescript
// API metrics
import { counter, histogram, gauge } from './metrics';

const httpRequests = counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labels: ['method', 'status', 'endpoint']
});

const httpDuration = histogram({
  name: 'http_request_duration_seconds',
  help: 'HTTP request duration',
  labels: ['method', 'endpoint']
});

const activeSubscriptions = gauge({
  name: 'subscription_active_total',
  help: 'Active subscriptions by plan'
});

// Usage
httpRequests.inc({ method: 'GET', status: 200, endpoint: '/health' });
activeSubscriptions.set({ plan: 'pro' }, 150);
```
