# 📋 Guide de Dépannage

**Date:** 2026-02-12  
**Dernière mise à jour:** 2026-02-12

---

## 🚨 Problèmes Critiques

### API ne démarre pas

**Symptômes:**
- `502 Bad Gateway` 
- Container en erreur

**Diagnostic:**

```bash
# 1. Vérifier status containers
docker-compose ps

# 2. Logs API
docker-compose logs api

# 3. Vérifier database connection
docker-compose exec api node -e "require('./src/config/database').test()"
```

**Causes fréquentes:**

| Cause | Solution |
|-------|----------|
| Database pas prête | `sleep 10` puis `docker-compose restart api` |
| Migrations non appliquées | `docker-compose run --rm api npx prisma migrate deploy` |
| Variables manquantes | Vérifier `.env` complet |
| Port déjà utilisé | `lsof -i :3000` |

**Résolution:**

```bash
# Solution complète
docker-compose down
docker-compose up -d postgres
sleep 10
docker-compose run --rm api npx prisma migrate deploy
docker-compose up -d
```

---

### Webhook Telegram ne fonctionne pas

**Symptômes:**
- Bot ne répond pas
- Erreur webhook

**Diagnostic:**

```bash
# Vérifier token
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe"

# Vérifier webhook
curl https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getWebhookInfo

# Tester envoi message
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
  -d "chat_id=YOUR_CHAT_ID&text=Test"
```

**Causes:**

| Code Erreur | Cause | Solution |
|------------|-------|----------|
| 401 Unauthorized | Token invalide | Vérifier `TELEGRAM_BOT_TOKEN` |
| 404 Not Found | Webhook pas configuré | `POST /setWebhook` |
| 403 Forbidden | Bot bloqué par utilisateur | Attendre |

**Configuration Webhook:**

```bash
# Définir webhook
curl -F "url=https://${DOMAIN}/telegram/webhook" \
     -F "secret_token=${TELEGRAM_WEBHOOK_SECRET}" \
  "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook"
```

---

### Paiements LemonSqueezy pas reçus

**Symptômes:**
- Abonnement pas activé
- Pas de webhook

**Diagnostic:**

```bash
# 1. Vérifier endpoint webhook
curl -I https://${DOMAIN}/lemonsqueezy/webhook

# 2. Logs webhook
docker-compose logs api | grep lemon

# 3. Tester signature
echo -n "test" | openssl dgst -sha256 -hmac "${LEMON_WEBHOOK_SECRET}"
```

**Vérification:**

```bash
# Liste webhooks configurés (API LemonSqueezy)
curl -H "Authorization: Bearer ${LEMON_API_KEY}" \
  "https://api.lemonsqueezy.com/v1/webhooks"
```

**Causes:**

| Problème | Solution |
|----------|----------|
| Webhook pas configuré | Créer webhook dans dashboard LemonSqueezy |
| Signature invalide | Vérifier `LEMON_WEBHOOK_SECRET` |
| Idempotence | Event déjà traité - vérifier `lemon_events` table |

---

## 🔧 Problèmes Techniques

### Pas de réponses IA

**Symptômes:**
- Bot répond pas
- Erreur "No AI provider"

**Diagnostic:**

```bash
# Vérifier Ollama
curl http://ollama:11434/api/tags

# Logs AI
docker-compose logs api | grep -i ai

# Vérifier clés client (BYOAI)
docker-compose exec api node -e "
require('./src/modules/api-keys/service').getUserKeys('user_id')
"
```

**Causes & Solutions:**

| Provider | Cause | Solution |
|----------|-------|----------|
| Ollama | Container HS | `docker-compose restart ollama` |
| OpenAI | Pas de clé client | Message utilisateur pour configurer |
| Claude | Pas de clé client | Message utilisateur pour configurer |

**Configuration:**

```bash
# Si Ollama HS, vérifier health
docker-compose exec ollama curl http://localhost:11434/api/tags
```

---

### Base de données lente

**Symptômes:**
- Timeouts
- Requêtes > 1s

**Diagnostic:**

```bash
# Connexion directe
docker-compose exec postgres psql -U telegram_ai

# Vérifier connexions
SELECT count(*) FROM pg_stat_activity;

# Queries lentes
SELECT pid, now() - query_start AS duration, query 
FROM pg_stat_activity 
WHERE state = 'active' 
ORDER BY duration DESC LIMIT 5;

# Index manquants
\d+ "User"
```

**Optimisations:**

```sql
-- Créer index manquants
CREATE INDEX CONCURRENTLY idx_messages_user_created 
ON "Message"(user_id, created_at DESC);

-- Vacuum analyze
VACUUM ANALYZE "Message";
```

---

### Rate Limiting

**Symptômes:**
- 429 Too Many Requests
- Blocage utilisateurs légitimes

**Diagnostic:**

```bash
# Vérifier Redis
docker-compose exec redis redis-cli KEYS "rate:*"

# Voir configuration
docker-compose exec api cat /app/.env | grep -i rate
```

**Ajustement:**

```env
# Aumenter limites dans .env
RATE_LIMIT_WINDOW=60000
RATE_LIMIT_MAX=100
```

---

## 📊 Monitoring

### Health Check

```bash
# Check complet
curl -s http://localhost:3000/health | jq .

# Réponse attendue:
{
  "status": "healthy",
  "services": {
    "database": "connected",
    "redis": "connected"
  },
  "uptime": 123456
}
```

### Métriques

```bash
# CPU / Memory
docker stats

# PostgreSQL connections
docker-compose exec postgres psql -c "SELECT count(*) FROM pg_stat_activity;"

# Redis memory
docker-compose exec redis redis-cli INFO memory
```

---

## 🆘 Récupération

### Rollback deployment

```bash
# Lister versions précédentes
docker images | grep telegram-ai

# Revenir à version précédente
docker-compose down
docker-compose pull telegram-ai:v1.x.x
docker-compose up -d
```

### Restore database

```bash
# Arrêter services
docker-compose down

# Restaurer backup
gunzip -c backups/postgres_YYYYMMDD_HHMMSS.dump.gz | \
  docker-compose exec -T postgres psql -U telegram_ai

# Redémarrer
docker-compose up -d
```

---

## 📞 Debug Avancé

### Activer logs détaillés

```env
# Dans .env
LOG_LEVEL=debug
DEBUG=*
```

### Inspector base

```bash
# Accès Prisma Studio
docker-compose exec api npx prisma studio
```

### Profiler requêtes

```bash
# Activer query logging
docker-compose exec api npm run db:log
```

---

## ✅ Checklist Debug

- [ ] Logs consultés
- [ ] Health check passé
- [ ] Base de données accessible
- [ ] Variables d'environnement vérifiées
- [ ] Containers redémarrés si nécessaire
- [ ] Rollback préparé avant changements
