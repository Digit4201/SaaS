# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM AI SAAS - Documentation Complète
# ═══════════════════════════════════════════════════════════════════════════════

## 📋 Table des Matières

1. [Installation Rapide](#installation-rapide)
2. [Configuration](#configuration)
3. [Déploiement Docker](#déploiement-docker)
4. [Endpoints API](#endpoints-api)
5. [Dépannage](#dépannage)
6. [Architecture](#architecture)

---

## 🚀 Installation Rapide

### Prérequis

- Node.js 20+
- PostgreSQL 15+
- Redis 7+ (optionnel)
- Ollama (optionnel, pour IA locale)

### Installation Locale

```bash
# 1. Cloner et installer les dépendances
cd telegram-ai-saas/api/
npm install

# 2. Configurer les variables d'environnement
cp ../.env.example .env
# Éditer .env avec vos valeurs

# 3. Générer le client Prisma
npx prisma generate

# 4. Créer les tables de la base de données
npx prisma migrate dev

# 5. Lancer l'API
npm run dev
```

### Lancer avec Docker

```bash
# Copier les variables d'environnement
cp .env.example .env
# Éditer .env

# Lancer tous les services
docker-compose up -d

# Voir les logs
docker-compose logs -f api
```

---

## ⚙️ Configuration

### Variables d'Environnement Obligatoires

```bash
# Database
DATABASE_URL="postgresql://user:pass@localhost:5432/db"

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_WEBHOOK_SECRET=your_webhook_secret

# Secrets (générer avec: openssl rand -hex 32)
JWT_SECRET=your_jwt_secret
ENCRYPTION_KEY=your_encryption_key

# Ollama (optionnel)
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3
```

### Variables Optionnelles

```bash
# Lemon Squeezy (paiements)
LEMON_API_KEY=your_lemon_key
LEMON_STORE_ID=your_store_id
LEMON_WEBHOOK_SECRET=your_webhook_secret

# Monitoring
SENTRY_DSN=your_sentry_dsn
```

---

## 🐳 Déploiement Docker

### Structure des Services

| Service | Port | Description |
|---------|------|-------------|
| api | 3000 | API principale Fastify |
| postgres | 5432 | Base de données |
| redis | 6379 | Cache et queues |
| caddy | 80,443 | Reverse proxy (TLS auto) |

### Commandes Docker

```bash
# Démarrer tous les services
docker-compose up -d

# Démarrer un service spécifique
docker-compose up -d postgres

# Arrêter tous les services
docker-compose down

# Voir les logs
docker-compose logs -f api

# Reconstruire après modification
docker-compose build api
docker-compose up -d api
```

### Production avec TLS

```bash
# Éditer Caddyfile avec votre domaine
nano Caddyfile

# Redémarrer Caddy
docker-compose restart caddy
```

---

## 📡 Endpoints API

### Authentication

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/auth/register` | Inscription Telegram |
| POST | `/auth/login` | Connexion email/password |
| GET | `/auth/me` | Profil utilisateur |

### Telegram

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/telegram/webhook` | Webhook Telegram (PUT) |
| POST | `/telegram/set-webhook` | Configurer webhook |
| GET | `/telegram/conversations` | Historique messages |

### Billing

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/billing/plans` | Liste des plans |
| POST | `/billing/checkout` | Créer checkout |
| GET | `/billing/subscription` | Abonnement utilisateur |
| GET | `/billing/payments` | Historique paiements |

### License

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/license/generate` | Générer licence (admin) |
| POST | `/license/activate` | Activer licence |
| GET | `/license/status` | Status licence |
| POST | `/license/verify` | Vérifier licence |

### AI

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/ai/chat` | Conversation IA |
| GET | `/ai/models` | Modèles disponibles |

### Web

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/web/search` | Recherche web |
| GET | `/web/fetch` | Fetch page web |

### Admin

| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/admin/stats` | Statistiques globales |
| GET | `/admin/users` | Liste utilisateurs |
| POST | `/license/generate` | Générer licence |

---

## 🔧 Dépannage

### Problèmes Courants

#### 1. Erreur de connexion PostgreSQL

```bash
# Vérifier que PostgreSQL tourne
docker-compose ps postgres

# Tester la connexion
docker-compose exec postgres psql -U postgres -d telegram_ai_saas

# Solution: Redémarrer PostgreSQL
docker-compose restart postgres
```

#### 2. Le bot Telegram ne répond pas

```bash
# Vérifier le webhook
curl https://api.telegram.org/bot<TOKEN>/getWebhookInfo

# Reconfigurer le webhook
curl -X POST https://api.telegram.org/bot<TOKEN>/setWebhook \
  -H "Content-Type: application/json" \
  -d '{"url": "https://votre-domaine.com/api/telegram/webhook"}'

# Vérifier les logs de l'API
docker-compose logs -f api
```

#### 3. Erreur "relation does not exist"

```bash
# Régénérer le client Prisma
npx prisma generate

# Appliquer les migrations
npx prisma migrate deploy

# Ou recréer la base
npx prisma migrate reset
```

#### 4. Ollama ne fonctionne pas

```bash
# Vérifier qu'Ollama tourne
curl http://localhost:11434/api/tags

# Télécharger un modèle
ollama pull llama3

# Vérifier les logs Ollama
docker-compose logs ollama
```

#### 5. Rate limiting activé

```bash
# Augmenter les limites dans .env
RATE_LIMIT_MESSAGES=200
RATE_LIMIT_API_KEYS=50

# Redémarrer l'API
docker-compose restart api
```

### Logs et Debug

```bash
# Logs en temps réel
docker-compose logs -f api

# Logs avec niveau debug
docker-compose exec api npm run dev -- --log-level debug

# Inspecter la base
docker-compose exec postgres psql -U postgres -d telegram_ai_saas
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Telegram User                           │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                  Telegram API                               │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                 Caddy (Reverse Proxy)                      │
│              TLS + Rate Limiting                           │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   Fastify API                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐    │
│  │ Auth     │ │ Telegram │ │ Billing  │ │ AI       │    │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘    │
└─────────────────────────┬───────────────────────────────────┘
                          │
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│  PostgreSQL   │ │    Redis     │ │    Ollama    │
│   (Primary)   │ │  (Cache/Q)   │ │   (Local AI) │
└──────────────┘ └──────────────┘ └──────────────┘
```

---

## 📊 Modèle de Données

```
User ──┬── Subscription ──► Plan
       ├── Message ──► AIUsage
       ├── Session
       ├── LicenseKey ──► LicenseActivation
       ├── Payment
       └── Invoice
```

---

## 🔒 Sécurité

- **JWT** pour l'authentification
- **bcrypt** pour les mots de passe
- **AES-256** pour les clés API stockées
- **Rate limiting** par IP et utilisateur
- **Helmet** pour les headers HTTP
- **CORS** configuré pour les origines autorisées

---

## 📈 Monitoring

### Lancer le Monitoring

```bash
# Lancer avec Prometheus, Grafana, Alertmanager
docker-compose -f docker-compose.monitoring.yml up -d

# Services de monitoring:
# - Prometheus: http://localhost:9090
# - Grafana:   http://localhost:3000 (admin/admin)
# - Alertmanager: http://localhost:9093
```

### Métriques Disponibles

| Métrique | Description |
|----------|-------------|
| `http_requests_total` | Nombre de requêtes HTTP |
| `http_request_duration_seconds` | Durée des requêtes (histogram) |
| `ai_requests_total` | Requêtes IA |
| `active_users` | Utilisateurs actifs |
| `total_users` | Total utilisateurs |
| `messages_today` | Messages aujourd'hui |
| `revenue_total` | Revenus totaux (€) |
| `active_subscriptions` | Abonnements actifs |
| `licenses_generated_total` | Licences générées |

### Dashboard Grafana

1. Accéder à Grafana: http://localhost:3000
2. Se connecter: admin/admin
3. Le dashboard `Telegram AI SaaS - Dashboard` est automatiquement importé

### Alerting

Les alertes sont configurées dans `monitoring/prometheus/rules/telegram-ai-alerts.yml`:

- **API Down** - API HS depuis 1 minute
- **High Error Rate** - Plus de 5% d'erreurs 5xx
- **High Latency** - Latence p95 > 2s
- **No New Users** - Pas de nouveaux users depuis 2h
- **Revenue Drop** - Revenus < 10€/24h
- **Redis Memory High** - Redis > 90% mémoire

### Intégration Email (SendGrid/Postmark)

```bash
# Configuration dans .env
EMAIL_PROVIDER=sendgrid  # ou postmark
SENDGRID_API_KEY=your_sendgrid_key
POSTMARK_SERVER_TOKEN=your_postmark_token
EMAIL_FROM=noreply@votre-domaine.com
EMAIL_FROM_NAME="Telegram AI Bot"

# Templates d'email:
# - Bienvenue (welcome)
# - Confirmation abonnement
# - Reçu de paiement
# - Annulation abonnement
# - Avertissement paiement échoué (dunning)
```

### Tests d'Intégration

```bash
# Lancer les tests
cd api/
npm test

# Tests disponibles:
# - Health endpoints
# - Billing (plans, checkout)
# - Auth (register, login)
# - Telegram webhook
# - License (status, verify)
# - Rate limiting
# - Database integration
```

---

## 📝 Notes de Version

Voir [CHANGELOG.md](./CHANGELOG.md)

## 📄 Licence

Voir [LICENSE](./LICENSE)

---

*Dernière mise à jour: 2026-02-12*
