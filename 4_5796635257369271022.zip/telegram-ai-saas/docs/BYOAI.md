# BYOAI - Modèle Hybride FINAL

**Date:** 2026-02-12  
**Status:** ✅ Implémenté

---

## Modèle Final

### Priorité IA (DÉFINITIF)

| Ordre | Source | Utilisation |
|-------|--------|-------------|
| 1 | **Ollama Local (Admin)** | ✅ PAR DÉFAUT pour tous |
| 2 | OpenAI Client | ✅ Si clé fournie |
| 3 | Claude Client | ✅ Si clé fournie |

### APIs Externes (BYOAI obligatoire)

| Service | Fourni par |
|---------|------------|
| Google/Gmail | Client - sa clé |
| GitHub | Client - sa clé |
| Moltbook | Client - sa clé |
| Brave | Client - sa clé |

---

## Flux de Sélection

```
┌─────────────────┐
│ Requête IA      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Ollama Local    │────▶│ ✓ DISPONIBLE?   │
│ (DÉFAUT)        │     │ → OUI → Utiliser │
└────────┬────────┘     └─────────────────┘
         │
    NON │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ OpenAI Client   │────▶│ ✓ CLÉ FOURNIE?  │
│ (Option)        │     │ → OUI → Utiliser │
└────────┬────────┘     └─────────────────┘
         │
    NON │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Claude Client   │────▶│ ✓ CLÉ FOURNIE?  │
│ (Option)        │     │ → OUI → Utiliser │
└────────┬────────┘     └─────────────────┘
         │
    NON │
         ▼
┌─────────────────┐
│  ERREUR:        │
│  Pas de provider│
└─────────────────┘
```

---

## Plateformes Supportées

| Platform | Type | Status |
|----------|------|--------|
| Ollama | IA Locale (Admin) | ✅ Par défaut |
| OpenAI | IA Client (Option) | ✅ |
| Claude Code | IA Client (Option) | ✅ |
| Brave | Web Search (Client) | ✅ |
| GitHub | API (Client) | ⏳ |
| Moltbook | API (Client) | ⏳ |
| Google/Gmail | API (Client) | ⏳ |

---

## Utilisation

```typescript
// Par défaut: Ollama local (gratuit)
const response = await aiAgent.generate(prompt, history, userId);

// Forcer OpenAI si disponible
const response = await aiAgent.generate(prompt, history, userId, {
  provider: 'openai'
});

// Forcer Claude si disponible
const response = await aiAgent.generate(prompt, history, userId, {
  provider: 'claude'
});
```

---

## Erreurs

```json
{
  "error": "OPENAI_API_KEY_REQUIRED",
  "message": "Configurez votre clé OpenAI pour utiliser GPT-4"
}

{
  "error": "CLAUDE_API_KEY_REQUIRED", 
  "message": "Configurez votre clé Claude pour utiliser Claude"
}

{
  "error": "BRAVE_API_KEY_REQUIRED",
  "message": "Configurez votre clé Brave pour la recherche web"
}
```

---

## Fichiers Modifiés

| Fichier | Description |
|---------|-------------|
| `api-keys.service.ts` | Chiffrement AES-256 |
| `api-keys.routes.ts` | CRUD API |
| `byoai.helper.ts` | Helper intégration |
| `ollama.service.ts` | Support 3 providers |
| `web-browse.routes.ts` | Brave client uniquement |

---

## Migration

```bash
cd /root/.openclaw/workspace/agents/techpartner/api
npx prisma migrate dev --name byoai_user_api_keys
```
