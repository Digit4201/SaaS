// ═══════════════════════════════════════════════════════════════════
// API KEY UTILITIES TEST
// Tests for encryption/decryption utilities
// ═══════════════════════════════════════════════════════════════════

describe('API Key Utilities', () => {
  
  describe('generateSecureToken', () => {
    const { generateSecureToken } = require('../../scripts/utils/api-keys');
    
    test('should generate token of correct length', () => {
      const token = generateSecureToken(32);
      expect(token).toHaveLength(64); // hex = 2x bytes
    });
    
    test('should generate unique tokens', () => {
      const token1 = generateSecureToken(32);
      const token2 = generateSecureToken(32);
      expect(token1).not.toBe(token2);
    });
    
    test('should only contain hex characters', () => {
      const token = generateSecureToken(32);
      expect(token).toMatch(/^[0-9a-f]+$/);
    });
  });
  
  describe('hashPassword', () => {
    const { hashPassword } = require('../../scripts/utils/api-keys');
    
    test('should hash password', () => {
      const password = 'testPassword123';
      const hash = hashPassword(password);
      
      expect(hash).toBeDefined();
      expect(hash).not.toBe(password);
    });
    
    test('should produce different hashes for same password', () => {
      const password = 'testPassword123';
      const hash1 = hashPassword(password);
      const hash2 = hashPassword(password);
      
      expect(hash1).not.toBe(hash2);
    });
  });
  
  describe('verifyPassword', () => {
    const { hashPassword, verifyPassword } = require('../../scripts/utils/api-keys');
    
    test('should verify correct password', () => {
      const password = 'testPassword123';
      const hash = hashPassword(password);
      
      expect(verifyPassword(password, hash)).toBe(true);
    });
    
    test('should reject incorrect password', () => {
      const password = 'testPassword123';
      const hash = hashPassword(password);
      
      expect(verifyPassword('wrongPassword', hash)).toBe(false);
    });
  });
});
