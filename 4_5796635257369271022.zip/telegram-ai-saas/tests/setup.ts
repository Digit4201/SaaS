// ═══════════════════════════════════════════════════════════════════
// JEST SETUP - Test configuration
// ═══════════════════════════════════════════════════════════════════

// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.TELEGRAM_WEBHOOK_SECRET = 'test-secret-key-for-testing-only';
process.env.ENCRYPTION_KEY = 'test-encryption-key-for-unit-tests-32';
process.env.SESSION_SECRET = 'test-session-secret-for-unit-tests-64';
process.env.JWT_SECRET = 'test-jwt-secret-for-unit-tests-64';

// Increase timeout for async tests
jest.setTimeout(10000);

// Mock console for cleaner test output
global.console = {
  ...console,
  log: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  // Keep error for debugging
  error: console.error
};
