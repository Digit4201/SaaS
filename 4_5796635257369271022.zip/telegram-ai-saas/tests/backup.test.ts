// ═══════════════════════════════════════════════════════════════════
// BACKUP SCRIPT TEST
// Tests for backup.sh functionality
// ═══════════════════════════════════════════════════════════════════

describe('Backup Script', () => {
  
  describe('backup filename generation', () => {
    // Mock Date for consistent testing
    beforeAll(() => {
      jest.useFakeTimers();
      jest.setSystemTime(new Date('2026-02-12T12:00:00Z'));
    });
    
    afterAll(() => {
      jest.useRealTimers();
    });
    
    test('should generate correct backup filename', () => {
      const { generateBackupFilename } = require('../../scripts/utils/backup');
      
      const filename = generateBackupFilename('postgres');
      expect(filename).toContain('postgres_20260212');
      expect(filename).toContain('.dump');
    });
  });
  
  describe('retention calculation', () => {
    const { calculateRetention } = require('../../scripts/utils/backup');
    
    test('should calculate correct number of files to delete', () => {
      const files = [
        { mtime: new Date('2026-02-01'), name: 'old.gz' },
        { mtime: new Date('2026-02-10'), name: 'recent.gz' },
        { mtime: new Date('2026-02-12'), name: 'today.gz' }
      ];
      
      const toDelete = calculateRetention(files, 7);
      expect(toDelete.length).toBe(1);
      expect(toDelete[0]).toBe('old.gz');
    });
  });
});
