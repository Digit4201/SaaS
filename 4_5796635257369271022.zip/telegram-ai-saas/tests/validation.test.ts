// ═══════════════════════════════════════════════════════════════════
// VALIDATION UTILITIES TEST
// Tests for input validation utilities
// ═══════════════════════════════════════════════════════════════════

describe('Validation Utilities', () => {
  
  describe('isValidEmail', () => {
    const { isValidEmail } = require('../../scripts/utils/validation');
    
    test('should accept valid emails', () => {
      expect(isValidEmail('test@example.com')).toBe(true);
      expect(isValidEmail('user.name@domain.org')).toBe(true);
      expect(isValidEmail('user+tag@example.co.uk')).toBe(true);
    });
    
    test('should reject invalid emails', () => {
      expect(isValidEmail('not-an-email')).toBe(false);
      expect(isValidEmail('@domain.com')).toBe(false);
      expect(isValidEmail('user@')).toBe(false);
      expect(isValidEmail('')).toBe(false);
    });
  });
  
  describe('isValidTelegramId', () => {
    const { isValidTelegramId } = require('../../scripts/utils/validation');
    
    test('should accept valid Telegram IDs', () => {
      expect(isValidTelegramId('123456789')).toBe(true);
      expect(isValidTelegramId('9876543210')).toBe(true);
    });
    
    test('should reject invalid Telegram IDs', () => {
      expect(isValidTelegramId('abc123')).toBe(false);
      expect(isValidTelegramId('')).toBe(false);
      expect(isValidTelegramId('123.456')).toBe(false);
    });
  });
  
  describe('sanitizeString', () => {
    const { sanitizeString } = require('../../scripts/utils/validation');
    
    test('should remove HTML tags', () => {
      expect(sanitizeString('<script>alert("xss")</script>')).toBe('alert("xss")');
      expect(sanitizeString('<b>Hello</b>')).toBe('Hello');
    });
    
    test('should trim whitespace', () => {
      expect(sanitizeString('  test  ')).toBe('test');
    });
    
    test('should handle normal strings', () => {
      expect(sanitizeString('normal string')).toBe('normal string');
    });
  });
  
  describe('isValidApiKey', () => {
    const { isValidApiKey } = require('../../scripts/utils/validation');
    
    test('should accept valid API keys', () => {
      expect(isValidApiKey('sk-abcdefghijklmnop')).toBe(true);
      expect(isValidApiKey('sk_test_1234567890abcdef')).toBe(true);
    });
    
    test('should reject invalid API keys', () => {
      expect(isValidApiKey('')).toBe(false);
      expect(isValidApiKey('invalid')).toBe(false);
    });
  });
});
