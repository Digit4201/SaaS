// ═══════════════════════════════════════════════════════════════════════════════
// TELEGRAM AI WORKER - Background Job Processor (CORRIGÉ)
// ═══════════════════════════════════════════════════════════════════════════════
//
// Implements BullMQ for:
// - AI message processing queue
// - Web scraping jobs
// - Analytics aggregation
// - Data retention jobs
//
// NOTE: This worker runs independently from the API.
// Configuration is loaded from environment variables.
// ═══════════════════════════════════════════════════════════════════════

import Bull from 'bullmq';
import { PrismaClient } from '@prisma/client';

// Simple logger (no dependency on api/src)
const logger = {
  info: (msg: string, meta?: any) => console.log(`[INFO] ${msg}`, JSON.stringify(meta || {})),
  error: (msg: string, meta?: any) => console.error(`[ERROR] ${msg}`, JSON.stringify(meta || {})),
  warn: (msg: string, meta?: any) => console.warn(`[WARN] ${msg}`, JSON.stringify(meta || {}))
};

// Configuration from environment
const config = {
  redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
  databaseUrl: process.env.DATABASE_URL || '',
  ollamaUrl: process.env.OLLAMA_URL || 'http://localhost:11434',
  ollamaModel: process.env.OLLAMA_MODEL || 'llama3'
};

// Initialize Prisma
const prisma = new PrismaClient({
  datasourceUrl: config.databaseUrl
});

// Redis connection
const redisConnection = {
  host: config.redisUrl.replace('redis://', '').split(':')[0] || 'localhost',
  port: parseInt(config.redisUrl.replace('redis://', '').split(':')[1] || '6379')
};

// Queue names
const QUEUES = {
  AI_PROCESSING: 'ai-processing',
  WEB_SCRAPING: 'web-scraping',
  ANALYTICS: 'analytics',
  DATA_RETENTION: 'data-retention'
} as const;

// ═══════════════════════════════════════════════════════════════════════
// AI PROCESSING QUEUE
// ═══════════════════════════════════════════════════════════════════════

const aiQueue = new Bull.Queue(QUEUES.AI_PROCESSING, { connection: redisConnection });

aiQueue.process(async (job) => {
  logger.info({ jobId: job.id, data: job.data }, 'Processing AI job');
  
  const { userId, messageId, prompt } = job.data;
  
  try {
    // Call Ollama
    const response = await fetch(`${config.ollamaUrl}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: config.ollamaModel,
        messages: [{ role: 'user', content: prompt }],
        stream: false
      })
    });

    if (!response.ok) {
      throw new Error('Ollama request failed');
    }

    const data = await response.json();
    const aiText = data.message?.content || data.response || 'Désolé, une erreur est survenue.';

    // Save AI response
    await prisma.message.create({
      data: {
        userId,
        role: 'ASSISTANT',
        content: aiText,
        aiModel: config.ollamaModel,
        platform: 'telegram'
      }
    });

    logger.info({ jobId: job.id }, 'AI job completed');
    return { success: true, response: aiText };
  } catch (error) {
    logger.error({ jobId: job.id, error }, 'AI job failed');
    throw error;
  }
});

// ═══════════════════════════════════════════════════════════════════════
// DATA RETENTION QUEUE
// ═══════════════════════════════════════════════════════════════════════

const retentionQueue = new Bull.Queue(QUEUES.DATA_RETENTION, { connection: redisConnection });

retentionQueue.process(async (job) => {
  logger.info({ jobId: job.id, type: job.data.type }, 'Running retention job');
  
  const { type = 'messages', retentionDays = 90 } = job.data || {};
  const cutoffDate = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
  
  try {
    let deletedCount = 0;
    
    if (type === 'messages' || type === 'all') {
      const result = await prisma.message.deleteMany({
        where: {
          createdAt: { lt: cutoffDate },
          deletedAt: null
        }
      });
      deletedCount = result.count;
    }
    
    logger.info({ jobId: job.id, type, deletedCount }, 'Retention job completed');
    return { deletedCount };
  } catch (error) {
    logger.error({ jobId: job.id, error }, 'Retention job failed');
    throw error;
  }
});

// ═══════════════════════════════════════════════════════════════════════
// SCHEDULE RETENTION JOBS
// ═══════════════════════════════════════════════════════════════════════

async function scheduleRetentionJobs() {
  // Schedule daily retention at 3 AM
  const cronTime = '0 3 * * *';
  
  await retentionQueue.add(
    'daily-retention',
    { type: 'all', retentionDays: 90 },
    { repeat: { pattern: cronTime } }
  );
  
  logger.info('Retention jobs scheduled');
}

// ═══════════════════════════════════════════════════════════════════════
// WORKER STARTUP
// ═══════════════════════════════════════════════════════════════════════

async function startWorker() {
  try {
    // Test database connection
    await prisma.$connect();
    logger.info('✅ Database connected');

    // Test Redis connection
    const testRedis = new Bull.Queue('test', { connection: redisConnection });
    await testRedis.add('test', { test: true });
    await testRedis.close();
    logger.info('✅ Redis connected');

    // Schedule retention jobs
    await scheduleRetentionJobs();

    logger.info(`
╔════════════════════════════════════════════════════════════╗
║  🚀 Telegram AI Worker Started (CORRIGÉ)                ║
║                                                            ║
║  Queues:                                                  ║
║  - ${QUEUES.AI_PROCESSING.padEnd(20)} Async AI responses              ║
║  - ${QUEUES.WEB_SCRAPING.padEnd(20)} Background web fetches          ║
║  - ${QUEUES.ANALYTICS.padEnd(20)} Metrics aggregation              ║
║  - ${QUEUES.DATA_RETENTION.padEnd(20)} Auto-cleanup (daily)          ║
╚════════════════════════════════════════════════════════════╝
    `);

    // Graceful shutdown
    const signals = ['SIGINT', 'SIGTERM'];
    signals.forEach(signal => {
      process.on(signal, async () => {
        logger.info(`Received ${signal}, shutting down...`);
        await aiQueue.close();
        await retentionQueue.close();
        await prisma.$disconnect();
        process.exit(0);
      });
    });

  } catch (error) {
    logger.error({ error }, 'Worker failed to start');
    process.exit(1);
  }
}

startWorker();

export { prisma, QUEUES, aiQueue, retentionQueue };
